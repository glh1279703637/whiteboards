//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    var m_dataArray : [[String]] = []
    var keyDic : [String : UIColor] = [:]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF22 : UITextField?
    var m_prefixTF23 : UITextField?
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    internal var m_clickBackCallback : kcompleteCallback?

    lazy var m_tableView : UITableView = {
        let tableView =  kcreateTableViewWithDelegate(self)
        return tableView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.m_tableView)
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 20), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        m_prefixTF22 = funj_getTextField("", "2022-11-11 10:22:20")
        m_prefixTF23 = funj_getTextField("", "2022-11-11 10:22:24")
        m_prefixTF = funj_getTextField("23", "排序字母数")
        m_prefixTF1 = funj_getTextField(",", "替换字")
        m_prefixTF2 = funj_getTextField(".", "被替换字")
    }
    func funj_getTextField(_ title : String, _ place : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x: self.width - 50, y: self.height - 30, width: 50, height: 30), placeholder: place, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.delegate = self
        prefixTF.text = title
        self.addSubview(prefixTF)
        return prefixTF
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_tableView.frame = self.bounds
        self.m_tableView.reloadData()
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF22?.left = self.width - 510; m_prefixTF22?.width = 180
        m_prefixTF22?.top = self.height - 30;
        m_prefixTF23?.left = self.width - 330;m_prefixTF23?.width = 180;
        m_prefixTF23?.top = self.height - 30;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 30;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 30;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 30;
    }
    func funj_reloadData() {
        self.m_tableView.reloadData()
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        m_clickBackCallback?()
    }
}
extension JLogContentTableView {
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.m_dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30;
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "NO. \(section + 1)"
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.m_dataArray[section].count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string = self.m_dataArray[indexPath.section][indexPath.row]
        if m_isOnlyShowInfo {
            var isHas = false
            for (key,_) in self.keyDic {
                if string.contains(key) {
                    isHas = true;
                }
            }
            if isHas == false {
                return 0
            }
        }
        
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        tableviewCell.setCellContent(content: self.m_dataArray[indexPath.section][indexPath.row], width: self.width - 20, keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArray[indexPath.section][indexPath.row]]
        return tableviewCell
    }
}

