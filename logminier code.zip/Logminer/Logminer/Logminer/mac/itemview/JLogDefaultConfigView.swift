//
//  JLogDefaultConfig.swift
//  Logminer
//
//  Created by Jeffrey on 2022/12/16.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

typealias klogDefaultCallback = ((_ key : String, _ add : Bool) -> ())

class JLogDefaultConfigCell : JBaseTableViewCell {
    var contentLabel : UILabel?
    var selectButton : UIButton?
    override func funj_addBaseTableSubView() {
        self.clipsToBounds = true
        contentLabel = UILabel(i: CGRect(x: 10, y: 0, width: 380, height: 30), title: nil, textFC: JTextFC(f: kFont_Size14, c: kColor_Text_Black))
        self.contentView.addSubview(contentLabel!)
        selectButton = UIButton(i: CGRect(x: 370, y: 0, width: 30, height: 30), title: "", textFC: JTextFC(f: kFont_Size13, c: kColor_Orange))
            .funj_add(bgImageOrColor: ["studying_rb_n", "studying_rb_s"], isImage: true)
        selectButton?.isUserInteractionEnabled = false
        self.contentView.addSubview(selectButton!)
    }
}

class JLogDefaultConfigView : JBaseTableViewVC, UITextFieldDelegate {
    internal var m_clickCallback : klogDefaultCallback?
    var m_saveSelectItem : [String] = []
    var m_searchTF : UITextField?
    var m_fileKey = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isHidden = true
        let label = UILabel(i: CGRect(x: 0, y: 0, width: 200, height: 20), title: "带##开头表示分区", textFC: JTextFC(f: kFont_Size12, c: kColor_Text_GRAY))
        self.view.addSubview(label)
        
        self.view.funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Orange))
        self.m_tableView.register(JLogDefaultConfigCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.separatorStyle = .singleLine
        
        let path2 = NSHomeDirectory() + "/Documents/logminer/\(m_fileKey)";
        if FileManager.default.fileExists(atPath: path2) == false {
            let url = URL(fileURLWithPath: path2)
            try? "".write(to: url, atomically: true, encoding: .utf8)
        }

        self.funj_reloadDatas()
        m_searchTF = UITextField(i: CGRectZero, placeholder: "搜索关键字", textFC: JTextFC(f: kFont_Size13, c: kColor_Orange)).funj_addCornerLayer(JFilletValue(w: 1, r: 3, c: kColor_Blue))
        m_searchTF?.delegate = self
        m_searchTF?.autocorrectionType = .no
        self.view.addSubview(self.m_searchTF!)
    }
    func funj_reloadDatas() {
        let path1 = NSHomeDirectory() + "/Documents/logminer/\(m_fileKey)select";
        let url1 = URL(fileURLWithPath: path1)
        if let data = try? String(contentsOf: url1, encoding: .utf8) {
            let dataArr = data.components(separatedBy: "\n")
            self.m_saveSelectItem.removeAll()
            for str in dataArr {
                self.m_saveSelectItem.append(str.lowercased())
            }
        }
        
        let path2 = NSHomeDirectory() + "/Documents/logminer/\(m_fileKey)";
        let url2 = URL(fileURLWithPath: path2)
        if let data = try? String(contentsOf: url2, encoding: .utf8) {
            let dataArr = data.components(separatedBy: "\n")
            self.m_dataArr.removeAll()
            self.m_dataArr += dataArr
            super.funj_reloadData()
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            self.m_tableView.reloadData()
        }
        return true
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table:CGRect(x: 0, y: 20, width: 400, height: self.view.height - 40))
        self.m_searchTF?.frame = CGRect(x: 0, y: self.view.height - 20, width: self.view.width, height: 20)
        self.m_tableView.reloadData()
    }
}
extension JLogDefaultConfigView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.m_searchTF!.text!.count > 0, let data = self.m_dataArr[indexPath.row] as? String {
            if !data.lowercased().contains(self.m_searchTF!.text!.lowercased()) {
                return 0
            }
        }
        return 30
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogDefaultConfigCell
        let key = self.m_dataArr[indexPath.row] as! String;
        tableviewCell.contentLabel?.text = key
        let isHead = (key.hasPrefix("##") || key.count == 0)
        tableviewCell.selectButton?.isSelected = self.m_saveSelectItem.contains(key.lowercased())
        tableviewCell.selectButton?.isHidden = isHead
        tableviewCell.contentLabel?.left = isHead ? 0 : 10
        tableviewCell.contentLabel?.textColor = isHead ? kColor_Text_GRAY : kColor_Text_Black
        tableviewCell.selectButton?.tag = indexPath.row
        return tableviewCell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let string = self.m_dataArr[indexPath.row] as! String;
        let isHead = (string.hasPrefix("##") || string.count == 0)
        if isHead { return }

        let cell = self.m_tableView.cellForRow(at: indexPath) as! JLogDefaultConfigCell
        if !self.m_saveSelectItem.contains(string.lowercased()) {
            self.m_saveSelectItem.append(string.lowercased())
            cell.selectButton?.isSelected = true
        } else {
            cell.selectButton?.isSelected = false
            self.m_saveSelectItem.removeAll { str in
                str == string.lowercased()
            }
        }
        self.m_clickCallback?(string, cell.selectButton!.isSelected)
    }
}
