//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : UIView, UITableViewDelegate, UITableViewDataSource {
    var m_dataArr : [String] = []
    var keyDic : [String : UIColor] = [:]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    lazy var m_tableView : UITableView = {
        let tableView =  kcreateTableViewWithDelegate(self)
        return tableView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.m_tableView)
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 20), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        m_prefixTF = funj_getTextField("23")
        m_prefixTF1 = funj_getTextField(",")
        m_prefixTF2 = funj_getTextField(".")
    }
    func funj_getTextField(_ title : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x: self.width - 50, y: self.height - 30, width: 50, height: 30), placeholder: "", textFC: JTextFC(f: kFont_Size14, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.text = title
        self.addSubview(prefixTF)
        return prefixTF
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_tableView.frame = self.bounds
        self.m_tableView.reloadData()
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 30;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 30;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 30;

    }
    func funj_reloadData() {
        self.m_tableView.reloadData()
    }
}
extension JLogContentTableView {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.m_dataArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string = self.m_dataArr[indexPath.row]
        if m_isOnlyShowInfo {
            var isHas = false
            for (key,_) in self.keyDic {
                if string.contains(key) {
                    isHas = true;
                }
            }
            if isHas == false {
                return 0
            }
        }
        
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        tableviewCell.setCellContent(content: self.m_dataArr[indexPath.row], width: self.width - 20, keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArr[indexPath.row]]
        return tableviewCell
    }
}

