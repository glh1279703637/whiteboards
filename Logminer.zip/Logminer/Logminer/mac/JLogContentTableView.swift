//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

typealias kSelectDateCallback = ((_ string : String) -> ())

class JLogContentTableView : UIView, UITextFieldDelegate, UITextViewDelegate {
    var m_dataArray : [[String]] = []
    var m_dataArr : [[String]] = []
    var keyDic : [String : UIColor] = [:]
    var m_saveMatchColorDic : [String : UIColor] = [ : ]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    var m_prefixTF4 : UITextField?
    var m_prefixTF5 : UITextField?
    var m_searchfixTF2 : UITextField?
    var m_searchCountLabel : UILabel?

    var m_startDate1 : String = ""
    var m_endDate1 : String = ""
    var m_searchRangeIndex : Int = 0
    var m_searchScrollMinRange = NSRange(location: 0, length: 0)
    var m_searchRangeIndexFromScroll = false
    var m_savePath : String = ""
    var m_saveSearchRangeArr : [NSRange] = []

    var itemSelectView : JItemSelectView?
    var m_splitScreenBt : UIButton?
    var m_saveContentBt : UIButton?
    var m_toBottomBt : UIButton?
    var m_saveOnlyContentBt : UIButton?
    var m_showDrawBt : UIButton?
    var m_splitTopPoint : CGFloat = kStatusBarHeight + 30
    var m_saveMatchLeftDic : [String : Int] = [:]
    var m_saveMatchLayerDic : [String : CAShapeLayer] = [:]
    var m_saveMatchPathDic : [String : UIBezierPath] = [:]
    var m_selectRowTitle : String?

    var m_subDeleteStrDic : [Int : Int] = [:]
    var m_saveRangeDic : [NSRange : Int] = [:]
    var m_saveRangeDic2 : [NSRange : Int] = [:]
    var m_saveSessionDic : [Int : NSRange] = [:]
    var m_saveConnectDic : [String : [[NSRange]]] = [:]
    
    var bgLeftView : UIView?
    var bgRightView : UIView?
    var m_shapeLayer : CAShapeLayer?
    var m_penDrawView : JMainPenDrawView?
    var m_addIndex : Int = 0
    var m_saveItemButtonArr : [UIButton] = []

    var m_contentAttri : NSMutableAttributedString?
    var m_contentString : String = ""
    var m_contentCount = 0
    
    internal var m_selectRowCallback : kSelectDateCallback?


    lazy var m_contentTV : UITextView = {
        let contentTV =  UITextView(i: CGRectZero, textFC: JTextFC())
        contentTV.textContainer.lineFragmentPadding = 10
        contentTV.delegate = self
        contentTV.isEditable = false
        return contentTV
    }()
    lazy var m_timer : Timer = {
        let timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(endActionToScroll), userInfo: nil, repeats: true)
        return timer
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)

        self.addSubview(self.m_contentTV)
        
        bgLeftView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        self.m_contentTV.addSubview(bgLeftView!)
        bgRightView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        self.m_contentTV.addSubview(bgRightView!)
        for i in 0..<200 {
           let addButton = UIButton(i: CGRect(x: 0, y: 0, width: 20, height: 20) , title: "", textFC: JTextFC())
                .funj_add(bgImageOrColor: ["course_copy_n"], isImage: true)
                .funj_addblock(block: { [weak self] button in
                    if let string = button.accessibilityLabel {
                        let isright = button.accessibilityValue
                        if isright?.count ?? 0 == 0 {
                            let string1 = (string as? NSString)?.substring(to: 19)
                            self?.m_selectRowCallback?(string1!)
                        } else {
                            self?.m_addIndex += 1
                            let button = UIButton(i: CGRect(x: self!.m_addIndex * 22, y: 30, width: 20, height: 20), title: "\(self!.m_addIndex)", textFC: JTextFC(f: kFont_Size10, c: kColor_White)).funj_add(targe: self!, action: "selectItemToScroll:", tag: 0).funj_add(bgImageOrColor: [kColor_Orange], isImage: false).funj_addCornerLayer(JFilletValue(w: 0, r: 10, c: kColor_Orange))
                            button.titleLabel?.adjustsFontSizeToFitWidth = true
                            button.accessibilityValue = string
                            self?.addSubview(button)
                        }
                    }
            })
            addButton.isHidden = true
            addButton.alpha = 0.3
            self.m_saveItemButtonArr.append(addButton)
        }
        
        m_penDrawView = JMainPenDrawView(frame: CGRect(x: 0, y: 0, width: self.width, height: self.height));
        m_penDrawView?.isUserInteractionEnabled = false
        self.addSubview(m_penDrawView!)
        
        itemSelectView = JItemSelectView()
        itemSelectView!.view.frame = CGRect(x: 80, y: 5, width: self.width - 150, height: 20)
        self.addSubview(itemSelectView!.view)
        itemSelectView?.m_selectCallback = { [weak self] (section) in
            self?.m_contentTV.scrollRangeToVisible((self?.m_saveSessionDic[section]) ?? NSRange(location: 0, length: 0))
        }
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 10), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.font = kFont_Size13
        titleLabel?.backgroundColor = kColor_Clear
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
        
        m_searchfixTF2 = JLogContentTableView.funj_getTextField("", "搜索定位")
        m_searchfixTF2?.width = 300
        m_searchfixTF2?.delegate = self
        self.addSubview(m_searchfixTF2!)
        m_searchfixTF2?.leftViewMode = .always
        m_searchfixTF2?.leftView = self.funj_getTextLeftView("向上")
        m_searchfixTF2?.rightViewMode = .always
        m_searchfixTF2?.rightView = self.funj_getTextLeftView("向下")
        m_searchCountLabel = UILabel(i: CGRect(x: m_searchfixTF2!.width - 40 - 40 , y: 0, width: 40, height: 20), title: "", textFC: JTextFC(f: kFont_Size14, c: kColor_Blue, a:.right))
        m_searchCountLabel?.adjustsFontSizeToFitWidth = true
        m_searchfixTF2?.addSubview(m_searchCountLabel!)

        m_toBottomBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "底部", callback: { [weak self] button in
            let range = NSRange(location: (self?.m_contentString.count ?? 10) - 10 , length: 1)
            self?.m_contentTV.scrollRangeToVisible(range)
            self?.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
        })
        
        m_saveContentBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "写入", callback: { [weak self] button in
            var string = ""
            for array in self?.m_dataArr ?? [] {
                string += array.joined(separator: "\n")
                string += "\n"
            }
            try? (string as? NSString)?.write(toFile: self!.m_savePath + ".txt", atomically: true, encoding: String.Encoding.utf8.rawValue)
        })
        m_saveOnlyContentBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "仅显示", callback: { [weak self] button in
            self?.m_isOnlyShowInfo = !self!.m_isOnlyShowInfo
            self?.funj_reloadData()
        })
        m_showDrawBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "画笔", callback: { [weak self] button in
            self?.m_penDrawView?.isUserInteractionEnabled = !self!.m_penDrawView!.isUserInteractionEnabled
            self!.m_penDrawView?.height = self!.m_contentTV.contentSize.height
            self!.m_penDrawView?.width = self!.m_contentTV.width
        })
        let stringlength = UserDefaults.standard.string(forKey: "subStringRangeLength") ?? "26:20"
        m_prefixTF4 = JLogContentTableView.funj_getTextField(stringlength, "减短(26:20)")
        m_prefixTF4?.delegate = self
        self.addSubview(m_prefixTF4!)
        m_prefixTF5 = JLogContentTableView.funj_getTextField("", "锁定 section序号 或者 开始/结束时间段")
        m_prefixTF5?.width = 300
        m_prefixTF5?.delegate = self
        self.addSubview(m_prefixTF5!)

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        self.funj_addCornerLayer(JFilletValue(w: 1, r: 3, c: kColor_Red))
        m_prefixTF = JLogContentTableView.funj_getTextField("23", "排序字母数")
        m_prefixTF1 = JLogContentTableView.funj_getTextField(",", "替换字")
        m_prefixTF2 = JLogContentTableView.funj_getTextField(".", "被替换字")
        self.addSubview(m_prefixTF!)
        self.addSubview(m_prefixTF1!)
        self.addSubview(m_prefixTF2!)
        
        m_splitScreenBt = funj_getButton(CGRect(x: self.width - 90, y: 0, width: 40, height: 20), title: "半屏", callback: { [weak self] button in
            self?.m_splitTopPoint = (self?.m_splitTopPoint ?? 0) > kStatusBarHeight + 30 ? kStatusBarHeight + 30 : (self?.height ?? 0) / 2
            self?.top = self?.m_splitTopPoint ?? 0
            self?.height = (self?.height ?? 0) - (self?.top ?? 0)
        })
    }
    static func funj_getTextField(_ title : String, _ place : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x:50, y: 30, width: 50, height: 20), placeholder: place, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.autocorrectionType = .no
        prefixTF.text = title
        return prefixTF
    }
    func funj_getButton(_ frame : CGRect, title : String, callback :kclickCallBack?) -> UIButton {
        let button = UIButton(i: frame, title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_White)).funj_add(bgImageOrColor: [kColor_Orange], isImage: false)
            .funj_addblock(block: callback)
        self.addSubview(button)
        return button
    }
    func funj_getTextLeftView(_ title : String) -> UIView {
        let view = UIView(i: CGRect(x: 0, y: 0, width: 40, height: 20), bg: kColor_Orange)
        let button = UIButton(i: CGRect(x: 0, y: 0, width: 40, height: 20), title: title, textFC: JTextFC(f: kFont_Size13, c: kColor_White))
            .funj_addblock { [weak self] button in
                if button.titleLabel?.text == "向上" {
                    self?.funj_searchContent(true)
                } else {
                    self?.funj_searchContent(false)
                }
            }
        view.addSubview(button)
        return view
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == m_searchfixTF2 {
            self.m_saveSearchRangeArr.removeAll()
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == m_prefixTF4 {
            if textField.text!.count > 0 {
                UserDefaults.standard.set(textField.text, forKey: "subStringRangeLength")
                UserDefaults.standard.synchronize()
            }
            self.funj_reloadData()
        } else if textField == m_prefixTF5 {
            self.funj_reloadData()
        } else if textField == m_searchfixTF2 {
            if m_searchfixTF2?.text?.count ?? 0 <= 0 {
                for (range2, v) in self.m_saveRangeDic2 {
                    self.m_contentAttri?.removeAttribute(.backgroundColor, range: range2)
                }
                self.m_contentTV.attributedText = self.m_contentAttri
                self.m_saveRangeDic2.removeAll()
                return true
            }
            
            let contentStr = self.m_contentString.lowercased() as? NSString
            let searchKey = textField.text!.lowercased()
            if self.m_saveSearchRangeArr.count == 0 {
                self.m_searchRangeIndex = -1
                var range = NSRange(location: 0, length: 0)
                var beginIndex = 0
                let lengths = contentStr!.length
                repeat {
                    range = contentStr!.range(of: searchKey, options: .forcedOrdering, range: NSRange(location: beginIndex, length: lengths - beginIndex))
                    if range.length > 0 {
                        self.m_saveSearchRangeArr.append(NSRange(location: range.location, length: min(1000, lengths - range.location)))
                    }
                    beginIndex = range.location + range.length
                } while(range.length > 0)
            }
            if self.m_searchRangeIndexFromScroll {
                let countd = self.m_saveSearchRangeArr.count
                for i in 0..<countd {
                    let range = self.m_saveSearchRangeArr[i]
                    if range.location > self.m_searchScrollMinRange.location {
                        self.m_searchRangeIndex = i - 1
                        break
                    }
                }
                self.m_searchRangeIndexFromScroll = false
            }
            self.m_searchRangeIndex += 1

            DispatchQueue.main.asyncAfter(deadline: .now()) {
                let countd = self.m_saveSearchRangeArr.count
                if self.m_searchRangeIndex >= countd {
                    self.m_searchRangeIndex = 0
                }
                if countd == 0 {
                    return
                }
                self.m_searchCountLabel?.text = "\(self.m_searchRangeIndex + 1)/\(countd)"
                self.m_contentTV.scrollRangeToVisible(self.m_saveSearchRangeArr[self.m_searchRangeIndex])
                self.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
            }
        }
        return false
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_contentTV.frame = CGRect(x: 0, y: 0, width: self.width, height: self.height)
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 20;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 20;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 20;
        m_prefixTF4?.left = self.width - 70;
        m_prefixTF4?.top = self.height - 40;
        m_prefixTF5?.left = self.width - 70 - m_prefixTF5!.width;
        m_prefixTF5?.top = self.height - 40;

        if self.titleLabel?.text == "Main" {
            m_searchfixTF2?.left = m_prefixTF!.left - m_searchfixTF2!.width;
        } else {
            if (self.superview?.superview?.frame.origin.x ?? 0) + self.frame.size.width < (self.superview?.superview?.superview?.width ?? 0) - 10 {
                m_searchfixTF2?.left = 0;
            } else {
                m_searchfixTF2?.left = self.width - 360 - m_searchfixTF2!.width;
            }
        }
        m_searchfixTF2?.top = self.height - 20;
        itemSelectView!.view.frame = CGRect(x: 80, y: 5, width: self.width - 150, height: 20)

        m_splitScreenBt?.left = self.width - 90
        let array = [m_toBottomBt, m_saveContentBt,m_saveOnlyContentBt,m_showDrawBt]
        var left = self.width - 10
        for button in array {
            button!.left = left - 45
            button!.top = self.height - 70
            left = button!.left
        }
        
        let maxHeight = max(self.m_contentTV.contentSize.height, self.m_contentTV.height)
        self.bgLeftView?.frame = CGRect(x: 0, y: 0, width: 20, height: maxHeight)
        self.bgRightView?.frame = CGRect(x: self.width - 20, y: 0, width: 20, height: maxHeight)
        self.m_shapeLayer?.frame = CGRect(x: 0, y: 0, width: self.m_contentTV.width, height: maxHeight)
        self.m_penDrawView?.height = maxHeight
        self.m_penDrawView?.width = self.m_contentTV.width
    }
    func funj_reloadButton() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.itemSelectView?.m_dataArr.removeAll()
            let countd = self.m_dataArr.count
            for index in 0..<countd {
                self.itemSelectView?.m_dataArr.append("\(index + 1)")
            }
            self.itemSelectView?.funj_reloadData()
        }
    }
    func funj_reloadToMatchValue() {
        if m_shapeLayer == nil {
            m_shapeLayer = CAShapeLayer()
            self.m_contentTV.layer.addSublayer(m_shapeLayer!)
            self.m_saveMatchLayerDic.removeAll()
        }
 
        m_shapeLayer?.frame = CGRect(x: 0, y: 0, width: self.m_contentTV.width, height: self.m_contentTV.contentSize.height)
        var isConnect = false
        for (key, color) in self.m_saveMatchColorDic {
            var arrayTotalRange = self.m_saveConnectDic[key];
            if arrayTotalRange == nil {
                arrayTotalRange = []
                let split = (key as NSString).range(of: "<>").length > 0 ? "<>" : "<~>"
                let array = key.components(separatedBy: split)
                isConnect = split == "<~>" ? true : false
                for key in array {
                    if self.keyDic[key] == nil {
                        self.keyDic[key] = color
                    }
                }
                
                let total = self.m_dataArr.count
                var maxLength = 0
                for inde in 0..<total { // session
                    let count = self.m_dataArr[inde].count
                    var indexfd = 0
                    var arrayRange : [NSRange] = []
                    for index in 0..<count {
                        let string = self.m_dataArr[inde][index]
                        let countdf = string.count
                        if isConnect {
                            for key1 in array {
                                let first = key1.lowercased()
                                if string.lowercased().contains(first) {
                                    let range1 = NSRange(location: maxLength, length: countdf)
                                    arrayRange.append(range1)
                                }
                            }
                        } else {
                            if indexfd >= array.count && indexfd > 0 {
                                indexfd = 0;
                                arrayTotalRange?.append(arrayRange)
                                arrayRange = []
                            }
                            let first = array[indexfd].lowercased()
                            if string.lowercased().contains(first) {
                                let range1 = NSRange(location: maxLength, length: countdf)
                                indexfd += 1
                                arrayRange.append(range1)
                            } else if indexfd > 0 {
                                for i in 0..<indexfd {
                                    let first = array[i].lowercased()
                                    if string.lowercased().contains(first) {
                                        let range1 = NSRange(location: maxLength, length: countdf)
                                        arrayTotalRange?.append([range1])
                                    }
                                }
                            }
                        }
                        maxLength += countdf + 1
                    }
                    maxLength -= 1
                    if arrayRange.count > 0 {
                        arrayTotalRange?.append(arrayRange)
                    }
                }
                if(arrayTotalRange!.count > 0) {
                    self.m_saveConnectDic[key] = arrayTotalRange!
                }
                var left2 = self.m_saveMatchLeftDic[key]
                if left2 == nil {
                    left2 = Int(arc4random() % 200) + 50
                    self.m_saveMatchLeftDic[key] = left2
                }
            }
            
            var shapeLayer = self.m_saveMatchLayerDic[key]
            if shapeLayer == nil {
                shapeLayer = CAShapeLayer()
                shapeLayer?.strokeColor = color.cgColor
                shapeLayer?.fillColor = nil
                shapeLayer?.lineWidth = 3
                self.m_saveMatchLayerDic[key] = shapeLayer
            }
            shapeLayer?.frame = self.m_shapeLayer!.bounds
            self.m_shapeLayer?.addSublayer(shapeLayer!)
        }
    }
    func funj_addMatchLine(_ left : Int, start : Int, end : Int, color : UIColor, rootPath : UIBezierPath) {
        let path = UIBezierPath()
        let startPoint = start + 10
        let endPoint = end + 30

        path.move(to: CGPoint(x: left + 30, y: startPoint))
        path.addLine(to: CGPoint(x: left, y: startPoint))
        path.addLine(to: CGPoint(x: left, y: endPoint))
        path.addLine(to: CGPoint(x: left + 30, y: endPoint))
        rootPath.append(path)
    }
    func funj_addNoMatchLine(start : Int, color : UIColor, rootPath : UIBezierPath) {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 30, y: start - 1))
        path.addLine(to: CGPoint(x: Int(self.m_contentTV.width) - 60, y: start))
        rootPath.append(path)
    }
    func funj_reloadData() {
        var session = 0
        var dataArray : [[String]] = []
        
        if let array = self.m_prefixTF4!.text?.components(separatedBy: ";") {
            self.m_subDeleteStrDic.removeAll()
            for str in array {
                if let array1 = str.components(separatedBy: ":") as [String]? {
                    let firstdelete = Int(array1.first ?? "0") ?? 0
                    let subdelete = Int(array1.last ?? "0") ?? 0
                    self.m_subDeleteStrDic[firstdelete] = subdelete
                }
            }
        }
        var lockIndex = 0
        var firstDate : String?
        var lastDate : String?
        var startLength = 0
        var endLength = 0
        if let lockStr = self.m_prefixTF5?.text {
            lockIndex = Int(lockStr) ?? 0
            if lockStr.contains("/") && lockIndex == 0 {
                let array = lockStr.components(separatedBy: "/")
                firstDate = array.first
                lastDate = array.last
                startLength = firstDate!.count
                endLength = lastDate!.count
            }
            if startLength <= 0 || endLength <= 0 { // 防止写过程中变化
                firstDate = nil
                lastDate = nil
                startLength = 0
                endLength = 0
            }
        }
        self.itemSelectView?.view?.isHidden = lockIndex > 0
        self.m_shapeLayer?.removeFromSuperlayer()
        self.m_shapeLayer = nil;
        self.m_saveRangeDic.removeAll()
        self.m_saveRangeDic2.removeAll()
        self.m_saveSessionDic.removeAll()
        self.m_saveConnectDic.removeAll()
        self.m_saveMatchLeftDic.removeAll()
        self.m_saveMatchLayerDic.removeAll()
        self.m_saveMatchPathDic.removeAll()
        self.m_contentString = ""
        self.m_contentCount = 0
        
        var measurements = [1.2, 1.5, 2.9, 1.2, 1.5]
        measurements.removeSubrange(1..<4)
        
        self.funj_updateMathToKey()
 
        var isstart = false
        var isend = true
        self.m_contentCount = 0
        for array in self.m_dataArray {
            var dataArr : [String] = []
            var sessionRow = 0
            session += 1
            dataArr.append("NO.\(session) ==>")
            if(lockIndex > 0 && session != lockIndex) {
                continue
            }
            var rowIndex = 1
            let arrays = array as [String]
            for var string in arrays {
                if startLength > 0 && endLength > 0 {
                    let contentLenght = string.count
                    if startLength > 0 && contentLenght >= startLength {
                        let key11 = (string as NSString).substring(to: startLength)
                        if key11 < firstDate! {
                            continue
                        }
                        isstart = true
                    } else if(!isstart) {
                        continue
                    }
                    if endLength > 0 && contentLenght >= endLength {
                        let key11 = (string as NSString).substring(to: endLength)
                        if key11 > lastDate! {
                            isend = false
                            continue
                        }
                        isend = true
                    } else if !isend {
                        continue
                    }
                }
                
                if self.m_subDeleteStrDic.count > 0 {
                    for (m_firstdelete, m_subdelete) in self.m_subDeleteStrDic {
                        if m_firstdelete + m_subdelete < string.count  && m_subdelete > 0 {
                            let start = string.index(string.startIndex, offsetBy: m_firstdelete)
                            let end = string.index(start, offsetBy: m_subdelete)
                            string.replaceSubrange(start..<end, with: " ")
                        }
                    }
                }
                
                string.insert(contentsOf: "\(rowIndex). ", at: string.startIndex)
                rowIndex += 1
                if m_isOnlyShowInfo {
                    var isHas = false
                    for (key,_) in self.keyDic {
                        if string.lowercased().contains(key.lowercased()) {
                            isHas = true;break
                        }
                    }
                    if isHas {
                        dataArr.append(string)
                        sessionRow += 1
                    }
                } else {
                    dataArr.append(string)
                    sessionRow += 1
                }
            }
            for _ in 0..<3 {
                dataArr.append("")
            }

            let content1 = dataArr.joined(separator: "\n")
            let countC = content1.count
            self.m_saveSessionDic[session] = NSRange(location: self.m_contentCount, length: min(countC, 1000))
            self.m_contentString += content1
            self.m_contentCount += countC
            dataArray.append(dataArr)
            
        }
        self.m_dataArr.removeAll()
        self.m_dataArr += dataArray
        self.funj_reloadToUpdateData()
                
        self.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
    }
    func funj_updateMathToKey() {
        for (keys, color) in self.m_saveMatchColorDic {
            let split = (keys as NSString).range(of: "<>").length > 0 ? "<>" : "<~>"
            let array = keys.components(separatedBy: split)
            for key in array {
                if self.keyDic[key] == nil {
                    self.keyDic[key] = color
                }
            }
        }
    }
    func funj_reloadToUpdateData () {
        self.m_contentTV.text = ""
        if self.m_contentCount <= 0 {
            return
        }
        let param = NSMutableParagraphStyle()
        param.lineSpacing = 0
        param.paragraphSpacing = 10
        param.firstLineHeadIndent = 10
        self.m_contentAttri = NSMutableAttributedString(string: self.m_contentString , attributes: [.font : kFont_Size16, .paragraphStyle : param]);

        var contentL = 0
        if keyDic.count > 0 {
            for dataArr in self.m_dataArr {
                for contents in dataArr {
                    for (key, value) in keyDic {
                        var range2 = (contents.lowercased() as NSString).range(of: key)
                        if range2.length > 0 {
                            range2.location += contentL
                            self.m_contentAttri?.addAttributes([.backgroundColor : value], range: range2);
                        }
                    }
                    contentL += contents.count + 1
                }
                contentL -= 1
            }
        }
        self.m_contentTV.attributedText = self.m_contentAttri
    }

    func funj_updateToScrollCell(_ date : String) {
        if date.count <= 0 || self.m_dataArr.count <= 0 { return }
        self.m_selectRowTitle = date
        
        let contentStr = self.m_contentString.lowercased() as NSString?
        let lengths = contentStr!.length
        var range = contentStr!.range(of: date, options: .forcedOrdering, range: NSRange(location: 0, length: lengths))
        range.length = min(1000, lengths - range.location)
        
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            if range.length > 0 {
                self.m_contentTV.scrollRangeToVisible(range)
                self.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
            }
        }
    }
    func funj_searchContent(_ isUp : Bool, _ isend : Bool = false) {
        let textField = self.m_searchfixTF2!
        if textField.text!.count <= 0 {
            return
        }
        if self.m_searchRangeIndexFromScroll {
            let countd = self.m_saveSearchRangeArr.count
            for i in 0..<countd {
                let range = self.m_saveSearchRangeArr[i]
                if range.location > self.m_searchScrollMinRange.location {
                    self.m_searchRangeIndex = i
                    break
                }
            }
            self.m_searchRangeIndexFromScroll = false
        }


        self.m_searchRangeIndex += isUp ? -1 : 1
        self.m_searchRangeIndex = (self.m_searchRangeIndex + self.m_saveSearchRangeArr.count) % max(self.m_saveSearchRangeArr.count, 1)
        
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            if self.m_searchRangeIndex >= self.m_saveSearchRangeArr.count { return }
            self.m_searchCountLabel?.text = "\(self.m_searchRangeIndex + 1)/\(self.m_saveSearchRangeArr.count)"
            self.m_contentTV.scrollRangeToVisible(self.m_saveSearchRangeArr[self.m_searchRangeIndex])
            self.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
        }
    }
}
extension JLogContentTableView {
    @objc func selectItemToScroll(_ sender : UIButton) {
        self.funj_updateToScrollCell(sender.accessibilityValue!)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.m_timer.fireDate = Date.distantFuture
        self.changeTextViewRangeToColor(scrollView, end:false);
        if scrollView == self.m_contentTV {
            let top = scrollView.contentOffset.y
            self.m_penDrawView?.top = -top

            if scrollView.isDragging && scrollView.isTracking && !scrollView.isDecelerating {
                self.scrollViewDidEndDecelerating(scrollView)
            }
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if self.m_searchfixTF2?.text?.count ?? 0 > 0 {
            self.m_searchRangeIndexFromScroll = true
        }
        self.scrollViewDidEndScrollingAnimation(scrollView)
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        self.m_timer.fireDate = Date(timeIntervalSinceNow: 1)
        self.m_penDrawView?.height = scrollView.contentSize.height
    }
    @objc func endActionToScroll() {
        self.m_timer.fireDate = Date.distantFuture
        self.funj_reloadToMatchValue()
        self.changeTextViewRangeToColor(self.m_contentTV, end:true);
    }
    func scrollTextViewAddSubView(_ pointArr: [CGFloat], _ titleArr: [String]) {
        let size = pointArr.count * 2
        for i in 0..<200 {
            let button = self.m_saveItemButtonArr[i];
            if i < size {
                var imageName = "course_copy_n"
                var isright : String? = nil
                let string1 = titleArr[i / 2]
                button.frame = CGRect(x: 0, y: pointArr[i / 2], width: 20, height: 20)
                button.isHidden = false
                button.accessibilityLabel = string1;
                if i % 2 == 1 {
                    imageName = "whiteboard_vote_vote_add"
                    isright = "1"
                    bgRightView?.addSubview(button)
                } else {
                    let contentLenght = string1.count;
                    let startLength = self.m_startDate1.count;
                    let endLength = self.m_endDate1.count;
                    var isHidden = true
                    
                    if startLength > 0 && contentLenght >= startLength {
                        let key11 = (string1 as NSString).substring(to: startLength)
                        if key11 >= self.m_startDate1 {
                            isHidden = false
                        }
                    }
                    if endLength > 0 && contentLenght >= endLength {
                        let key11 = (string1 as NSString).substring(to: endLength)
                        if key11 > self.m_endDate1 {
                            isHidden = true
                        }
                    }
                    
                    if !isHidden {
                        imageName = "star"
                    }
                    bgLeftView?.addSubview(button)
                }
                button.setImage(UIImage(named: imageName), for: .normal)
                button.accessibilityValue = isright;
            } else {
                button.isHidden = true
            }
        }
    }
    func changeTextViewRangeToColor(_ scrollView: UIScrollView, end: Bool) {
        let offset = scrollView.contentOffset
        let rect = CGRect(x: offset.x, y: offset.y, width: scrollView.width, height: scrollView.height)
        let layoutManager:NSLayoutManager = self.m_contentTV.textStorage.layoutManagers[0]
        let textContainer:NSTextContainer = layoutManager.textContainers[0]
        let range = layoutManager.glyphRange(forBoundingRect: rect, in: textContainer)
        if !end || range.length <= 0 {
            return
        }

        var content = self.m_contentString.lowercased() as NSString?
        content = content?.substring(with: range) as NSString?
        if let contentArr = content?.components(separatedBy: "\n") as [NSString]? {
            self.m_searchScrollMinRange = range

            var pointArray : [CGFloat] = []
            var titleArray : [String] = []
            var searchRange = NSRange(location: 0, length: 0)
            if self.m_searchRangeIndex < self.m_saveSearchRangeArr.count {
                searchRange = self.m_saveSearchRangeArr[self.m_searchRangeIndex]
            }
            let colorArr = [kColor_Clear, kRGB(red: 0.2, green: 0, blue: 0, alpha: 0.1),kRGB(red: 0.7, green: 0, blue: 0, alpha: 0.2),kRGB(red: 0.4, green: 0, blue: 0, alpha: 0.2)]

            var start = range.location
            var isChange = false
            for content2 in contentArr {
                var isCellBackgroudColor = 0
                let maxLength1 = content2.length
                let range1 = content2.range(of: ". 202")
                if range1.length > 0 {
                    if maxLength1 - (range1.location + 2) >= 26 {
                        let frame = layoutManager.boundingRect(forGlyphRange: NSRange(location: start + range1.location, length: range1.length), in: textContainer)
                        pointArray.append(frame.origin.y + 5)
                        let title = content2.substring(with: NSRange(location: range1.location + 2, length: 26))
                        titleArray.append(title as String)
                    }
                    if let search = self.m_searchfixTF2?.text, search.count > 0 {
                        let range2 = content2.range(of:search)
                        if range2.length > 0 {
                            isCellBackgroudColor = 1
                            if searchRange.location >= start + range2.location {
                                isCellBackgroudColor = 2
                            }
                        }
                    }
                    if let search = self.m_selectRowTitle, search.count > 0 {
                        let range2 = content2.range(of:search)
                        if range2.length > 0 {
                            isCellBackgroudColor = 3
                        }
                    }
                    
                    let range2 = NSRange(location: start, length: maxLength1)
                    if isCellBackgroudColor > 0 {
                        if self.m_saveRangeDic2[range2] != isCellBackgroudColor {
                            if self.m_saveRangeDic2[range2] != nil {
                                self.m_saveRangeDic2.removeValue(forKey: range2)
                                self.m_contentAttri?.removeAttribute(.backgroundColor, range: range2)
                            }
                            self.m_saveRangeDic2[range2] = isCellBackgroudColor
                            self.m_contentAttri?.addAttributes([.backgroundColor : colorArr[isCellBackgroudColor]], range: range2)
                            isChange = true
                        }

                    } else if self.m_saveRangeDic2[range2] != nil {
                        self.m_saveRangeDic2.removeValue(forKey: range2)
                        self.m_contentAttri?.removeAttribute(.backgroundColor, range: range2)
                    }
                }
                start += maxLength1 + 1
            }
            
            if titleArray.count > 0 {
                self.scrollTextViewAddSubView(pointArray, titleArray)
            }
            if isChange {
                self.m_contentTV.attributedText = self.m_contentAttri
            }
        }
        let start = range.location
        let maxLength1 = range.length
        for (key, color) in self.m_saveMatchColorDic {
            if let arrayTotalRange = self.m_saveConnectDic[key] {
                let rootPath = UIBezierPath()
                self.m_saveMatchPathDic[key] = rootPath

                for arrayRange in arrayTotalRange {
                    let range1 = arrayRange.first!
                    if range1.location > range.location + range.length {
                        break
                    }
                    if arrayRange.count == 1 {
                        if range1.location + range1.length >= start {
                            self.funj_reloadMatchLineToView(key, color: color, rangeArr: arrayRange)
                        }
                    } else {
                        let range2 = arrayRange.last!
                        if range2.location + range2.length < range.location  {
                            continue
                        }

                        if (range1.location > start && range1.location < start + maxLength1) ||
                            (range1.location + range1.length > start  && range1.location + range1.length < start + maxLength1) ||
                            (range2.location > start && range2.location < start + maxLength1) ||
                                (range2.location + range2.length > start  && range2.location + range2.length < start + maxLength1) ||
                            (range1.location < start && range2.location + range2.length > start + maxLength1) {
                            self.funj_reloadMatchLineToView(key, color: color, rangeArr: arrayRange)
                        }
                    }
                }
            }
        }
    }
    func funj_reloadMatchLineToView(_ key : String, color : UIColor, rangeArr : [NSRange] ) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            let layoutManager:NSLayoutManager = self.m_contentTV.textStorage.layoutManagers[0]
            let textContainer:NSTextContainer = layoutManager.textContainers[0]
            let left2 = self.m_saveMatchLeftDic[key]!
            let shapeLayer = self.m_saveMatchLayerDic[key]!
            let rootPath = self.m_saveMatchPathDic[key]!
             var upTop = Int(layoutManager.boundingRect(forGlyphRange: rangeArr[0], in: textContainer).origin.y)
            let countd = rangeArr.count
            if countd == 1 {
                self.funj_addNoMatchLine( start: upTop + 20, color: color, rootPath: rootPath)
            } else {
                for i in 1..<countd {
                    let top = Int(layoutManager.boundingRect(forGlyphRange: rangeArr[i], in: textContainer).origin.y)
                    self.funj_addMatchLine(left2 ,start: upTop, end: top, color: color, rootPath: rootPath)
                    upTop = top
                }
            }
            shapeLayer.path = rootPath.cgPath
        }
        
    }
    
}

