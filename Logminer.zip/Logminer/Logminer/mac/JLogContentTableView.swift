//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    var m_dataArray : [[String]] = []
    var keyDic : [String : UIColor] = [:]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    
    var m_startDate1 : String = ""
    var m_endDate1 : String = ""

    lazy var m_tableView : UITableView = {
        let tableView =  kcreateTableViewWithDelegate(self)
        return tableView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.m_tableView)
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 20), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        m_prefixTF = JLogContentTableView.funj_getTextField("23", "排序字母数")
        m_prefixTF1 = JLogContentTableView.funj_getTextField(",", "替换字")
        m_prefixTF2 = JLogContentTableView.funj_getTextField(".", "被替换字")
        self.addSubview(m_prefixTF!)
        self.addSubview(m_prefixTF1!)
        self.addSubview(m_prefixTF2!)
    }
    static func funj_getTextField(_ title : String, _ place : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x:50, y: 30, width: 50, height: 30), placeholder: place, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.text = title
        return prefixTF
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_tableView.frame = self.bounds
        self.m_tableView.reloadData()
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 30;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 30;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 30;
    }
    func funj_reloadData() {
        self.m_tableView.reloadData()
    }
}
extension JLogContentTableView {
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.m_dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30;
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "NO. \(section + 1)"
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.m_dataArray[section].count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string = self.m_dataArray[indexPath.section][indexPath.row]
        if m_isOnlyShowInfo {
            var isHas = false
            for (key,_) in self.keyDic {
                if string.contains(key) {
                    isHas = true;
                }
            }
            if isHas == false {
                return 0
            }
        }
        
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        let string = self.m_dataArray[indexPath.section][indexPath.row]
        tableviewCell.setCellContent(content: string, width: self.width - 20, keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArray[indexPath.section][indexPath.row]]
        var left = 10
        let index = Int(self.m_prefixTF?.text ?? "36")
        if self.m_startDate1.count > 0 && string.count >= index! {
            let key11 = (string as NSString).substring(to: index!) as! String
            if key11 >= self.m_startDate1 {
                left = 30
            }
        }
        if self.m_endDate1.count > 0 && string.count >= index! {
            let key11 = (string as NSString).substring(to: index!) as! String
            if key11 > self.m_endDate1 {
                left = 10
            }
        }
        tableviewCell.contentLabel?.left = CGFloat(left)
        return tableviewCell
    }
}

