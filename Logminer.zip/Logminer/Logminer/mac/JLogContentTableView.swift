//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : JBaseTableViewVC {
    var keyDic : [String : UIColor] = [:]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 20), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.view.addSubview(titleLabel!);
    }
    func funj_reloadMainContentView() {
        m_prefixTF = funj_getTextField("23")
        m_prefixTF1 = funj_getTextField(",")
        m_prefixTF2 = funj_getTextField(".")
    }
    func funj_getTextField(_ title : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x: self.view.width - 50, y: self.view.height - 30, width: 50, height: 30), placeholder: "", textFC: JTextFC(f: kFont_Size14, c: kColor_Red))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.text = title
        self.view.addSubview(prefixTF)
        return prefixTF
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table: self.view.bounds)
        self.m_tableView.reloadData()
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.view.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.view.width - 150;
        m_prefixTF?.top = self.view.height - 30;
        m_prefixTF1?.left = self.view.width - 100;
        m_prefixTF1?.top = self.view.height - 30;
        m_prefixTF2?.left = self.view.width - 50;
        m_prefixTF2?.top = self.view.height - 30;

    }
}
extension JLogContentTableView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string : NSString = self.m_dataArr[indexPath.row] as! NSString
        if m_isOnlyShowInfo {
            var isHas = false
            for (key,_) in self.keyDic {
                if string.contains(key) {
                    isHas = true;
                }
            }
            if isHas == false {
                return 0
            }
        }
        
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.view.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        tableviewCell.setCellContent(content: self.m_dataArr[indexPath.row] as! NSString, width: self.view.width - 20, keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArr[indexPath.row] as! String]
        return tableviewCell
    }
}

