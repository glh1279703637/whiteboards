//
//  JLogContentCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    override func funj_addBaseTableSubView() {
        self.clipsToBounds = true
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 0, height: 0), textFC: JTextFC(f: kFont_Size15, c: kColor_Text_Black))
        contentLabel?.isEditable = false
        contentLabel?.isScrollEnabled = false;
        self.contentView.addSubview(contentLabel!)
    }
    func setCellContent(content : NSString, width : CGFloat, keyDic : [String : UIColor]) {
        contentLabel?.width = width;
        let attri = NSMutableAttributedString(string: content as! String, attributes: [.font : kFont_Size15]);
        for (key, value) in keyDic {
            let range = content.range(of: key);
            if range.length > 0 {
                attri.addAttributes([.foregroundColor : value, .font : kFont_Size16], range: range);
            }
        }
        contentLabel?.attributedText = attri;

        let size = JAppUtility.funj_getTextW_Height(content as String, textFont: kFont_Size20, layoutwidth: width, layoutheight: 500)
        contentLabel?.height = size.height + 10;
    }
}
