//
//  JLogFileCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogFileCell : JBaseTableViewCell {
    var contentLabel : UILabel?
    override func funj_addBaseTableSubView() {
        contentLabel = UILabel(frame: CGRect(x: 10, y: 0, width: 350, height: 30))
        self.contentView.addSubview(contentLabel!)
    }
}
