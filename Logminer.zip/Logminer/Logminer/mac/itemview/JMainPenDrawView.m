//
//  JMainPenDrawView.m
//  DoubleColorBall
//
//  Created by Jeffrey on 2020/3/29.
//  Copyright © 2020 Jeffrey. All rights reserved.
//

#import "JMainPenDrawView.h"
@implementation JLineModel

-(id)init{
    if(self =[super init]){
        _lineArray=[[NSMutableArray alloc]init];
    }
    return self;
}
@end

@interface JMainPenDrawView ()
@property(nonatomic,strong)NSTimer *m_timer;
@property(nonatomic,strong)NSMutableArray *m_lineArr;
@property(nonatomic,strong)NSNumber *m_selectLineColor;
@property(nonatomic,assign)BOOL m_shouldDraw;
@property(nonatomic,strong)NSMutableDictionary *m_saveLineLayerDic;
@end

@implementation JMainPenDrawView
-(id)initWithFrame:(CGRect)frame{
    if(self =[super initWithFrame:frame]){
        self.opaque = NO;
        self.layer.masksToBounds = YES;
        self.backgroundColor = [UIColor clearColor];
        _m_timer =[NSTimer scheduledTimerWithTimeInterval:0.1 target:self  selector:@selector(funj_startDrawLine:) userInfo:nil  repeats:YES];

        _m_lineArr =[[NSMutableArray alloc]init];
        _m_selectLineColor =@(0xf04d4d);
        self.m_bezierPathType = kPen_bezierPath;
        
        _m_saveLineLayerDic =[[NSMutableDictionary alloc]init];
        [self funj_addButtonSubviews];
    }
    return self;
}
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000)>>16))/255.0 green:((float)((rgbValue & 0xFF00)>>8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define COLOR_GREEN            UIColorFromRGB(0x33c764)//绿色 /
#define COLOR_RED UIColorFromRGB(0xf04d4d) //红色
#define COLOR_TEXT_BLACK       UIColorFromRGB(0x333333)//字体黑色 /
#define COLOR_ORANGE           UIColorFromRGB(0xff8338)//橘色 /
#define COLOR_BLUE             UIColorFromRGB(0x3899ff)//状态栏的颜色 蓝色 /
#define COLOR_WHITE            UIColorFromRGB(0xffffff)//白色
#define PUBLIC_FONT_SIZE15        [UIFont systemFontOfSize:15]

-(void)funj_addButtonSubviews{
    NSArray *titleArr = @[@"撤回",@"清空",@"红",@"蓝",@"黑",@"橙"];
    NSArray *colorArr = @[COLOR_GREEN,COLOR_GREEN ,COLOR_RED,COLOR_BLUE,COLOR_TEXT_BLACK,COLOR_ORANGE];

    for(int i=0;i<titleArr.count;i++){
        UIButton *itemBt =[self funj_getButton:28 * i :titleArr[i]  :@[colorArr[i]]  :@"funj_selectChangeColor:" :21100+i];
        [self insertSubview:itemBt atIndex:2];
    }
    titleArr = @[@"画笔",@"直线",@"矩形"];
    colorArr = @[COLOR_GREEN,COLOR_GREEN,COLOR_GREEN];

    for(int i=0;i<titleArr.count;i++){
        UIButton *itemBt =[self funj_getButton:28 * i + 6 * 28 :titleArr[i] :@[colorArr[i]]  :@"funj_selectChangeLine:" :21200+i];
        [self addSubview:itemBt];
    }
}
-(UIButton*)funj_getButton:(CGFloat)left :(NSString*)title :(NSArray*)bgImageOrColor  :(NSString*)action :(NSInteger)tags{
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(left, 40, 27, 20)];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button setBackgroundColor:bgImageOrColor.firstObject];
    [button addTarget:self action:NSSelectorFromString(action) forControlEvents:UIControlEventTouchUpInside];
    button.tag = tags;
    button.hidden = YES;
    return button;
}
-(void)funj_selectChangeColor:(UIButton*)sender{
    if(sender.tag == 21100){
        [self funj_cancelLastLine];
    }else if(sender.tag == 21101){
        [self funj_deleteAllLine];
    }else{
        NSArray *colorArr = @[@(0xf04d4d),@(0x3899ff),@(0x000000),@(0xff8338)];
        self.m_selectLineColor = colorArr[sender.tag - 21102];
    }
}
-(void)funj_selectChangeLine:(UIButton*)sender{
    self.m_bezierPathType = sender.tag - 21200+1;
}


-(void)funj_startDrawLine:(NSTimer*)timer{
    if(!self.m_shouldDraw)return;
    [self funj_drawLineToView];
    self.m_shouldDraw = NO;
}
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled{
    [super setUserInteractionEnabled:userInteractionEnabled];
    if(self.m_timer.isValid){
        if(!userInteractionEnabled)[self.m_timer setFireDate:[NSDate distantFuture]];
        else [self.m_timer setFireDate:[NSDate distantPast]];
    }
    for(int i=0;i<6;i++){
        UIButton *itemBt =[self viewWithTag:21100+i];
        itemBt.hidden = !userInteractionEnabled;
     }
    for(int i=0;i<6;i++){
        UIButton *itemBt =[self viewWithTag:21200+i];
        itemBt.hidden = !userInteractionEnabled;
     }

}

-(void)funj_cancelLastLine{
    JLineModel *model =[self.m_lineArr lastObject];
    if(model){
        CAShapeLayer *polygonLayer =[self.m_saveLineLayerDic objectForKey:model.key];
        [polygonLayer removeFromSuperlayer];
        [self.m_saveLineLayerDic removeObjectForKey:model.key];
        [self.m_lineArr removeObject:model];
    }
}
-(void)funj_deleteAllLine{
    [self.m_lineArr removeAllObjects];
    for(CAShapeLayer *polygonLayer in self.m_saveLineLayerDic.allValues){
        [polygonLayer removeFromSuperlayer];
    }
    [self.m_saveLineLayerDic removeAllObjects];
}


#pragma mark touch
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [[touches allObjects] firstObject];
    CGPoint p = [touch locationInView:self];
 
    [self onPointCollected:p type:kDrawPointStart];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesMoved:touches withEvent:event];
    UITouch *touch = [[touches allObjects] firstObject];
    CGPoint p = [touch locationInView:self];
 
    [self onPointCollected:p type:kDrawPointMove];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesEnded:touches withEvent:event];
    UITouch *touch = [[touches allObjects] firstObject];
    CGPoint p = [touch locationInView:self];
 
    [self onPointCollected:CGPointMake(p.x+0.01, p.y+0.01) type:kDrawPointEnd];
 }

- (void)onPointCollected:(CGPoint)p type:(DrawPointType)type{
    JLineModel *lineModel = nil;
    if(type == kDrawPointStart){
        lineModel =[[JLineModel alloc]init];
        lineModel.m_bezierPathType = self.m_bezierPathType;
        lineModel.lineColor = self.m_selectLineColor;
        lineModel.key =[NSString stringWithFormat:@"%f",[NSDate timeIntervalSinceReferenceDate]];
        [self.m_lineArr addObject:lineModel];
    }else{
        lineModel = [self.m_lineArr lastObject];
    }
    [lineModel.lineArray addObject:[NSValue valueWithCGPoint:p]];
    self.m_shouldDraw = YES;
}
-(void)funj_drawLineToView{
    if(self.m_lineArr.count <= 0) return;
    
    JLineModel* lineModel =[self.m_lineArr lastObject];
    UIBezierPath *path = nil;
    switch (lineModel.m_bezierPathType) {
        case kPen_bezierPath: {
            path =  [self funj_drawWithPenSubView:lineModel ];
        }break;
        case kVectorLine_bezierPath:{
            path = [self funj_drawToVectorLine:lineModel];
        }break;
        case kRect_bezierPath:{
            path = [self funj_drawToRectOrArc:lineModel :NO];
        }break;
        default:
            break;
    }
    CAShapeLayer *polygonLayer =[self.m_saveLineLayerDic objectForKey:lineModel.key];
    if(polygonLayer){
        polygonLayer.path = path.CGPath;
    }else{
        polygonLayer = [CAShapeLayer layer];
        polygonLayer.lineWidth = 2;
        UIColor *color = UIColorFromRGB([lineModel.lineColor intValue]);
        polygonLayer.strokeColor = color.CGColor;
        polygonLayer.path = path.CGPath;
        polygonLayer.fillColor = nil; // 默认为blackColor
        [self.layer addSublayer:polygonLayer];
        [self.m_saveLineLayerDic setObject:polygonLayer forKey:lineModel.key];
    }
}
//通过画笔方式 绘制线条
-(UIBezierPath*)funj_drawWithPenSubView:(JLineModel*)lineModel  {
    UIBezierPath *path = [UIBezierPath bezierPath];
    NSInteger index = 0;
    for(NSValue *value in lineModel.lineArray){
        if(index == 0){
            [path moveToPoint:[value CGPointValue]];
            index ++;
        }else{
            [path addLineToPoint:[value CGPointValue]];
        }
    }
    return path;
}
//绘制矢量直线
-(UIBezierPath*)funj_drawToVectorLine:(JLineModel*)line {
    UIBezierPath* path =[UIBezierPath bezierPath];;
    CGPoint startP = [[line.lineArray firstObject] CGPointValue];
    CGPoint endP = [[line.lineArray lastObject] CGPointValue];
    startP = CGPointMake(startP.x, startP.y);
    endP = CGPointMake(endP.x, endP.y);
    
    [path moveToPoint: CGPointMake(startP.x, startP.y)];
    [path addLineToPoint:CGPointMake(endP.x, endP.y)];
    
    return path;
    
}
//绘制圆形 方形
-(UIBezierPath*)funj_drawToRectOrArc:(JLineModel*)line :(BOOL)isArc{
    UIBezierPath* path =nil;
    CGPoint startP = [[line.lineArray firstObject] CGPointValue];
    CGPoint endP = [[line.lineArray lastObject] CGPointValue];
    startP = CGPointMake(startP.x, startP.y);
    endP = CGPointMake(endP.x, endP.y);
    CGFloat width = endP.x - startP.x;
    CGFloat height = endP.y-startP.y ;
    
    if(isArc){
        path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(startP.x, startP.y, width, height)];
    }else{
        path=[UIBezierPath bezierPathWithRect:CGRectMake(startP.x, startP.y,width, height)];
    }
    return path;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    for(int i = 0;i<10;i++) {
        UIButton *but = [self viewWithTag:21100 + i];
        CGRect frame = but.frame;
        frame.origin.y = 40 + self.m_offTop;
        but.frame = frame;
    }
    for(int i = 0;i<10;i++) {
        UIButton *but = [self viewWithTag:21200 + i];
        CGRect frame = but.frame;
        frame.origin.y = 40 + self.m_offTop;
        but.frame = frame;
    }
}

@end
