//
//  JLogFileItem.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

typealias klogFileCallback = ((_ path : String, _ title : String ,_ data :[[String]]) -> ())

class JLogFileItemView : JBaseTableViewVC, UITextFieldDelegate {
    internal var m_logFileCallback : klogFileCallback?
    var m_pathTF : UITextField?
    var m_splitTF : UITextField?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.m_tableView.register(JBaseTableViewCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.separatorStyle = .singleLine
        
        m_pathTF = UITextField(i: CGRect(x: 0, y: 0, width: 350, height: 30), placeholder: "Path", textFC: JTextFC(f: kFont_Size14, c: kColor_Text_Black)).funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_Red))
        m_pathTF?.delegate = self
        self.view.addSubview(m_pathTF!)
        m_pathTF?.text = UserDefaults.standard.string(forKey: "pathTitleContent")
        if m_pathTF!.text!.count <= 0 {
            m_pathTF?.text = NSHomeDirectory() + "/Desktop"
        }
        m_pathTF?.autocorrectionType = .no

        m_splitTF = UITextField(i: CGRect(x: 0, y: 470, width: 400, height: 30), placeholder: "分割点", textFC: JTextFC(f: kFont_Size14, c: kColor_Text_Black)).funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_Red))
        m_splitTF?.delegate = self
        self.view.addSubview(m_splitTF!)
        m_splitTF?.text = UserDefaults.standard.string(forKey: "splitTitleContent")
        m_splitTF?.autocorrectionType = .no

        let closeBt = UIButton(i: CGRect(x: 400-60, y: 0, width: 60, height: 30), title: "Close", textFC: JTextFC(f: kFont_Size14, c: kColor_Red))
            .funj_addblock { [weak self] button in
                self?.view.isHidden = !(self?.view.isHidden ?? false)
            }
        self.view.addSubview(closeBt)
        
        NotificationCenter.default.addObserver(self, selector: #selector(funj_addContentField(_ :)), name: Notification.Name(rawValue: "postFileToMainNotifaction")  , object: nil)
    }
    func funj_reloadDatas() {
        let root = self.m_pathTF!.text!
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                let fileList = try? FileManager.default.contentsOfDirectory(atPath: self.m_pathTF!.text!)
                self.m_dataArr.removeAll();
                self.m_dataArr += fileList!
                super.funj_reloadData()
            }
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table:CGRect(x: 0, y: 30, width: 400, height: self.view.height - 60))
        self.m_tableView.reloadData()
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == m_pathTF {
            UserDefaults.standard.set(textField.text, forKey: "pathTitleContent")
            UserDefaults.standard.synchronize()
            self.funj_reloadDatas()
        } else {
            UserDefaults.standard.set(textField.text, forKey: "splitTitleContent")
            UserDefaults.standard.synchronize()
        }
    }
}
extension JLogFileItemView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string : NSString = self.m_dataArr[indexPath.row] as! NSString
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.view.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JBaseTableViewCell
        let basePath = self.m_dataArr[indexPath.row];
        tableviewCell.textLabel?.text = (basePath as? NSString)?.lastPathComponent
        let root = self.m_pathTF!.text!.appending("/").appending(self.m_dataArr[indexPath.row] as! String)
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                tableviewCell.backgroundColor = kColor_Blue
            } else {
                tableviewCell.backgroundColor = kColor_Bg_Shallow_Lightgray_Dark
            }
        }
        return tableviewCell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var root = self.m_pathTF!.text!
        if !root.hasSuffix("/") {
            root += "/"
        }
        root += self.m_dataArr[indexPath.row] as! String
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                if let fileList = try? FileManager.default.contentsOfDirectory(atPath: root) {
                    var row = indexPath.row + 1;
                    for path2 in fileList {
                        var path3 = (self.m_dataArr[indexPath.row] as! String);
                        path3.append("/")
                        path3.append(path2)
                        if (self.m_dataArr as! [String]).contains(path3) == false {
                            self.m_dataArr.insert(path3, at: row)
                            row += 1
                        }
                    }
                    self.funj_reloadData()
                }
            } else {
                self.readDataToMainInfo(root, title: self.m_dataArr[indexPath.row] as! String)
            }
        }
    }
    @objc func funj_addContentField(_ notifaction : Notification) {
        if let url = notifaction.object as? URL {
            let root = url.deletingLastPathComponent()
            self.m_pathTF?.text = root.path
            let title = url.lastPathComponent
            self.readDataToMainInfo(url.path, title: title)
        }
    }
    func readDataToMainInfo(_ root : String, title : String) {
        if let data = try? String(contentsOfFile: root) {
            let array = data.components(separatedBy: self.m_splitTF!.text!)
            var dataArr : [[String]] = []
            for str in array {
                if str.count <= 0 {
                    continue
                }
                var array1 = str.components(separatedBy: "\n")
                array1.insert(self.m_splitTF!.text!, at: 0)
                dataArr.append(array1)
            }
            m_logFileCallback?(root, title, dataArr)
        }
    }
}
