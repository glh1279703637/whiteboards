//
//  JLogFileItem.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

typealias klogFileCallback = ((_ title : String ,_ data :[String]) -> ())

class JLogFileItemView : JBaseTableViewVC {
    internal var m_logFileCallback : klogFileCallback?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.m_tableView.register(JBaseTableViewCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.separatorStyle = .singleLine
        
        let closeBt = UIButton(i: CGRect(x: 350-60, y: 0, width: 60, height: 30), title: "Close", textFC: JTextFC(f: kFont_Size14, c: kColor_Red))
            .funj_addblock { [weak self] button in
                self?.view.isHidden = !(self?.view.isHidden ?? false)
            }
        self.view.addSubview(closeBt)
    }
    func funj_reloadDatas() {
        let root = NSHomeDirectory().appending("/tmp")
        let fileList = try? FileManager.default.contentsOfDirectory(atPath: root)
        self.m_dataArr.removeAll();
        self.m_dataArr += fileList!
        super.funj_reloadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table: self.view.bounds)
        self.m_tableView.reloadData()
    }
}
extension JLogFileItemView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string : NSString = self.m_dataArr[indexPath.row] as! NSString
        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.view.width - 20, layoutheight: 500)
        return size.height + 15
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JBaseTableViewCell
        tableviewCell.textLabel?.text = self.m_dataArr[indexPath.row] as? String
        let root = NSHomeDirectory().appending("/tmp/").appending(self.m_dataArr[indexPath.row] as! String)
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                tableviewCell.backgroundColor = kColor_Blue
            } else {
                tableviewCell.backgroundColor = kColor_Bg_Shallow_Lightgray_Dark
            }
        }
        return tableviewCell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let root = NSHomeDirectory().appending("/tmp/").appending(self.m_dataArr[indexPath.row] as! String)
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                if let fileList = try? FileManager.default.contentsOfDirectory(atPath: root) {
                    var row = indexPath.row + 1;
                    for path2 in fileList {
                        var path3 = (self.m_dataArr[indexPath.row] as! String);
                        path3.append("/")
                        path3.append(path2)
                        if (self.m_dataArr as! [String]).contains(path3) == false {
                            self.m_dataArr.insert(path3, at: row)
                            row += 1
                        }
                    }
                    self.funj_reloadData()
                }
            } else {
                if let data = try? String(contentsOfFile: root) {
                    let array = data.components(separatedBy: "\n")
                    m_logFileCallback?(self.m_dataArr[indexPath.row] as! String, array)
                }
            }
        }
    }
}
