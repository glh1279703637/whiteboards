//
//  JMainPenDrawView.h
//  DoubleColorBall
//
//  Created by Jeffrey on 2020/3/29.
//  Copyright © 2020 Jeffrey. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, DrawPointType) {
     kDrawPointStart     = 1, //开始
     kDrawPointMove      = 2,  //移动
     kDrawPointEnd       = 3,  //结束

};
//线的类型
typedef  NS_ENUM(NSUInteger,BezierPathType){
    kPen_bezierPath = 1,
    kVectorLine_bezierPath,
    kRect_bezierPath,
};

@interface JLineModel : NSObject
//线色
 @property(nonatomic,strong) NSNumber* lineColor;
//线坐标
@property(nonatomic,strong)NSMutableArray *lineArray;

@property(nonatomic,assign) BezierPathType  m_bezierPathType;

@property(nonatomic,copy)NSString *key;

@end

@interface JMainPenDrawView : UIView
@property(nonatomic,assign) BezierPathType  m_bezierPathType;

@end

NS_ASSUME_NONNULL_END
