//
//  JLogHistoryView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/12/16.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogHistoryViewCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    var selectButton : UIButton?
    var openButton : UIButton?
    var bgImageView : UIImageView?
    
    var m_saveRootPath : String = ""
    override func funj_addBaseTableSubView() {
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 390, height: 300), textFC: JTextFC(f: kFont_Size14, c: kColor_Text_Black))
        contentLabel?.isEditable = false
        self.backgroundColor = krandomColors(alpha: 0.1)
        self.contentView.addSubview(contentLabel!)
        
        selectButton = UIButton(i: CGRect(x: 330, y: 0, width: 30, height: 30), title: "重载", textFC: JTextFC(f: kFont_Size13, c: kColor_Orange))
            .funj_add(t: 3, e: false)
            .funj_add(targe: self , action: "funj_reloadResetContent", tag: 0)
            
        self.contentView.addSubview(selectButton!)
        
        selectButton = UIButton(i: CGRect(x: 370, y: 0, width: 30, height: 30), title: "打开", textFC: JTextFC(f: kFont_Size13, c: kColor_Orange))
            .funj_add(t: 3, e: false)
            .funj_addblock(block: { button in
                let url = URL(fileURLWithPath: self.m_saveRootPath)
                UIApplication.shared.open(url, options: [UIApplication.OpenExternalURLOptionsKey.universalLinksOnly : false], completionHandler: nil)
            })
        self.contentView.addSubview(selectButton!)
        
        bgImageView = UIImageView(i: CGRect(x: 5, y: 300, width: 390, height: 300), image: nil)
        bgImageView?.contentMode = UIView.ContentMode.scaleAspectFit
        bgImageView?.isUserInteractionEnabled = true
        bgImageView?.backgroundColor = kColor_Text_Black
        self.contentView.addSubview(bgImageView!)
        var saveImageTop = 0
        bgImageView?.funj_whenTapped({ [weak self]view in
            if view.width > 510 {
                view.frame = CGRect(x: 5, y: saveImageTop, width: 390, height: 300)
                self?.contentView.addSubview(view)
            } else {
                saveImageTop = Int(view.top)
                if let superView = self?.superview?.superview?.superview {
                    view.frame = CGRect(x: 0, y: kStatusBarHeight, width: superView.width , height: superView.height - kStatusBarHeight)
                    superView.addSubview(view)
                }
            }
        })
    }
    @objc func funj_reloadResetContent() {
        let nameArr = self.m_saveRootPath.components(separatedBy: "/")
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: "postFileToResetViewNotifaction"), object: nameArr[nameArr.count - 2])
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            let path2 = self.m_saveRootPath + "openFile.txt"
            let url2 = URL(fileURLWithPath: path2)
            if let texts = try? String(contentsOf: url2, encoding: .utf8)  {
                let URLContexts = texts.components(separatedBy: "\n")
                for path in URLContexts {
                    if path.count <= 0 { continue }
                    NotificationCenter.default.post(name: Notification.Name(rawValue: "postFileToMainNotifaction"), object: URL(fileURLWithPath: path))
                }
            }
            self.superview?.superview?.isHidden = true
        }
    }
}

class JLogHistoryView : JBaseTableViewVC {
    internal var m_clickCallback : klogDefaultCallback?
    var m_saveSelectItem : [String] = []
    var m_saveRowHeight : [String : CGFloat] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isHidden = true
        self.view.funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Orange))
        self.m_tableView.register(JLogHistoryViewCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.separatorStyle = .singleLine
        NotificationCenter.default.addObserver(self, selector: #selector(funj_reloadResetContent), name: Notification.Name(rawValue: "resetpostFileToMainNotifaction")  , object: nil)
    }
    func funj_reloadDatas() {
        self.m_saveRowHeight.removeAll()
        let root = NSHomeDirectory() + "/Documents/logminer/history/";
        var isDir : ObjCBool = false
        if FileManager.default.fileExists(atPath: root, isDirectory: &isDir) {
            if isDir.boolValue {
                if var fileList = try? FileManager.default.contentsOfDirectory(atPath: root) {
                    fileList = fileList.sorted { str1, str2 in
                        str1 > str2
                    }
                    var dataArr : [[String : String]] = []
                    for title in fileList {
                        if title.hasPrefix(".") { continue }
                        var dic : [String : String] = [:]
                        var content = title + "\n"
                        let path2 = root + title + "/readme.txt"
                        let url2 = URL(fileURLWithPath: path2)
                        if let texts = try? String(contentsOf: url2, encoding: .utf8)  {
                            content += texts
                        }
                        dic["content"] = content
                        if let searchText = self.m_searchBar.m_searchTF?.text, searchText.count > 0 {
                            guard title.lowercased().contains(searchText.lowercased()) || content.lowercased().contains(searchText.lowercased()) else {
                                continue
                            }
                        }
                        let path3 = root + title + "/result.png"
                        if FileManager.default.fileExists(atPath: path3) {
                            dic["imagePath"] = path3
                        }
                        dic["root"] = root + title + "/"
                        dataArr.append(dic)
                    }
                    self.m_dataArr.removeAll()
                    self.m_dataArr += dataArr
                }
            }
        }
        super.funj_reloadData()
    }
    @objc func funj_reloadResetContent() {
        if let tableviewCell = self.m_tableView.visibleCells.first as? JLogHistoryViewCell {
            tableviewCell.funj_reloadResetContent()
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRect(x: 0, y: 0, width: 400, height: 30), table:CGRect(x: 0, y: 30, width: 400, height: self.view.height), isHidden:false)
        self.m_tableView.reloadData()
    }
}
extension JLogHistoryView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var size : CGFloat = 50
        if let dic = self.m_dataArr[indexPath.row] as? [String : String] {
            if let size2 = self.m_saveRowHeight[dic["root"]!] {
                return size2
            }
            size = CGFloat(JAppUtility.funj_getTextW_Height(dic["content"], textFont: kFont_Size14, layoutwidth: 390, layoutheight: 300).height) + 20
            size = max(50, size)
            size = min(300, size)
            if dic["imagePath"]?.count ?? 0 > 0 {
                size += 300
            }
            self.m_saveRowHeight[dic["root"]!] = size
        }
        return size
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogHistoryViewCell
        if let dic = self.m_dataArr[indexPath.row] as? [String : String] , var size = self.m_saveRowHeight[dic["root"]!] {
            
            tableviewCell.bgImageView?.isHidden = true
            if dic["imagePath"]?.count ?? 0 > 0 {
                tableviewCell.bgImageView?.isHidden = false
                size -= 300
                tableviewCell.bgImageView?.image = UIImage(contentsOfFile: dic["imagePath"]!)
            }
            tableviewCell.contentLabel?.height = size
            tableviewCell.bgImageView?.top = size
            tableviewCell.contentLabel?.text = dic["content"]
            tableviewCell.m_saveRootPath = dic["root"]!
        }
        return tableviewCell
    }
    
    override func funj_searchCancelButtonClicked(_ textField : UITextField) {
        super.funj_searchCancelButtonClicked(textField)
        self.funj_reloadDatas()
    }
    override func funj_searchDidEndEditing(_ textField : UITextField) {
        self.funj_reloadDatas();
    }
}
