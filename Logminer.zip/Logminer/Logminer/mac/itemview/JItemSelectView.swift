//
//  JItemSelectView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/12/11.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit
typealias kSelectSectionCallback = ((_ section : Int) -> ())

class JItemSelectViewCell : JBaseCollectionViewCell {
    var titleLabel : UILabel?
    override func funj_addBaseCollectionView() {
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 56, height: 20), title: nil, textFC: JTextFC(f: kFont_Size12, c: kColor_White, a: .center))
        titleLabel?.backgroundColor = kARGBHex(0xff8338,0.6)
        self.contentView.addSubview(titleLabel!)
    }
}

class JItemSelectView : JBaseCollectionVC {
    internal var m_selectCallback : kSelectSectionCallback?
    override func viewDidLoad() {
        super.viewDidLoad()
        let flowlayout = self.m_collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flowlayout.scrollDirection = .horizontal
        self.view.backgroundColor = kColor_Clear

        
        self.m_collectionView.register(JItemSelectViewCell.self, forCellWithReuseIdentifier: kCellIndentifier)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table: self.view.bounds)
    }
}
extension JItemSelectView {
    override func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 56, height: collectionView.height)
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: kCellIndentifier, for: indexPath) as! JItemSelectViewCell
        cell.titleLabel?.text = "NO. " + ((self.m_dataArr[indexPath.row]) as! String)
        return cell
    }
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        m_selectCallback?(indexPath.row + 1)
    }
}

