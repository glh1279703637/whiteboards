project_dir="/Users/jeffrey/Desktop/aa/";

loginfile="/Users/jeffrey/Desktop/aa/logfile.txt";

cat "$loginfile" | while read line; do #属性

path=${line%;;;*}
log=${line##*;;;}
#echo $log
#echo $path
#echo $project_dir$path

linenum=`sed -n -e "/$log/=" $project_dir$path`
arr=($linenum)
echo ${arr[0]}

#linenum2=`cat -n "$project_dir$path" | grep "$log" |awk '{print $1}'`
#arr2=($linenum2)
#echo ${arr2[0]}



done
