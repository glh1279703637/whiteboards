//
//  DESBase64.m
//  Text
//
//  Created by Jeffrey on 15/8/12.
//  Copyright (c) 2015年 Jeffrey. All rights reserved.
//

#import "JDESBase64.h"
#import "
.h"
//空字符串
#define     LocalStr_None           @""
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>

static const char encodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

@implementation JDESBase64

+ (NSString *)funj_encryptionWithbase64:(NSString *)text k:(NSString*)key{
    if (text && ![text isEqualToString:LocalStr_None]) {
        
          NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
        //IOS 自带DES加密 Begin
        data = [self funj_DESEncrypt:data k:[self encryptionKey:key]];
        //IOS 自带DES加密 End
        return [self funj_base64EncodedStringFrom:data];
    }
    else {
        return LocalStr_None;
    }
    NSLog(@"idecryptionWithbase64o id %@", [NSString string]);
    
    NSLog(@"idecrypt333ionWo id %@", [NSString string]);

    NSLog(@"idecrypt333ionWo id %@", NSStringstring)

    NSLog(@"idecrypt333ionWo id %@", [NSString string]);

}
@end
