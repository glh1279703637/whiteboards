//
//  JLogContentCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit
typealias kSelectDateCallback = ((_ string : String) -> ())

class JLogContentCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    var topImageView : UIImageView?
    var syncButton : UIButton?
    var addButton : UIButton?
    internal var m_selectCallback : kSelectDateCallback?
    internal var m_selectCallback2 : kSelectDateCallback?

    var isCellBackgroudColor = 0 { // 多种类型数据
        willSet {
            if newValue == 1 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.2, green: 0, blue: 0, alpha: 0.1)
            } else if newValue == 2 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
            } else if newValue == 3 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
            } else {
                self.contentLabel?.backgroundColor = nil
            }
        }
    }
    var addLeft : Int = 0 {
        willSet {
            self.contentLabel?.left = CGFloat(newValue)
            self.contentLabel?.width =  self.width - CGFloat(newValue) - 20
        }
    }

    override func funj_addBaseTableSubView() {
        topImageView = UIImageView(i: CGRect(x: 0, y: 0, width: 20, height: 20), image: "star")
        topImageView?.contentMode = .scaleAspectFit
        syncButton = UIButton(i: CGRect(x: 0, y: 3, width: 20, height: 20) , title: "", textFC: JTextFC())
            .funj_add(bgImageOrColor: ["course_copy_n"], isImage: true)
            .funj_addblock(block: { [weak self] button in
            if let string = self?.contentLabel?.attributedText.string  as? NSString {
                var start = string.range(of: ". 2")
                var indexd = 0;
                if(start.length == 0) {
                    indexd = 1
                    start = string.range(of: ". [2")
                }
                if(start.length > 0) {
                    let ss = string.substring(with: NSRange(location: start.location+2+indexd, length: 19))
                    self?.m_selectCallback?(ss as String)
                }
            }
        })
        syncButton!.addSubview(topImageView!)

        
        self.clipsToBounds = true
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 0, height: 0), textFC: JTextFC(f: kFont_Size15, c: kColor_Text_Black, a:.center))
        contentLabel?.isEditable = false
//        contentLabel?.isScrollEnabled = false;
        self.contentView.addSubview(contentLabel!)
        self.contentView.addSubview(syncButton!)
        
        contentLabel?.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        addButton = UIButton(i: CGRect(x: self.width - 20, y: 3, width: 20, height: 20) , title: "", textFC: JTextFC())
            .funj_add(bgImageOrColor: ["whiteboard_vote_vote_add"], isImage: true)
            .funj_addblock(block: { [weak self] button in
                if let string = self?.contentLabel?.attributedText.string  as? NSString {
                    var start = string.range(of: ". 2")
                    var indexd = 0;
                    if(start.length == 0) {
                        indexd = 1
                        start = string.range(of: ". [2")
                    }
                    if(start.length > 0) {
                        let ss = string.substring(with: NSRange(location: start.location+2+indexd, length: 26))
                        self?.m_selectCallback2?(ss as String)
                    }
                }
        })
        addButton?.alpha = 0.3
        self.contentView.addSubview(addButton!)
    }
    func setCellContent(content : NSMutableAttributedString) {
        contentLabel?.attributedText = content;
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if let textView = object as? UITextView {
            let height = textView.attributedText.boundingRect(with: CGSize(width: textView.width, height: 500), options: .usesLineFragmentOrigin, context: nil).height
            var topCorrect = textView.height - height
            if topCorrect <= 0 {
                topCorrect = 0
            }
            textView.textContainerInset = UIEdgeInsets(top: topCorrect/2, left: 0, bottom: 0, right: 0)
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        contentLabel?.left = 10
        contentLabel?.width = self.size.width - 20;
        contentLabel?.height = self.size.height;
        syncButton?.height = self.size.height - 6;
        addButton?.left = self.size.width - 20
        topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y)
    }
}
