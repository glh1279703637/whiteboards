//
//  JLogContentCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    var topImageView : UIImageView?
    override func funj_addBaseTableSubView() {
        topImageView = UIImageView(i: CGRect(x: 0, y: 0, width: 20, height: 20), image: "star")
        self.contentView.addSubview(topImageView!)
        topImageView?.contentMode = .scaleAspectFit
        
        self.clipsToBounds = true
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 0, height: 0), textFC: JTextFC(f: kFont_Size15, c: kColor_Text_Black))
        contentLabel?.isEditable = false
        contentLabel?.isScrollEnabled = false;
        self.contentView.addSubview(contentLabel!)
    }
    func setCellContent(content : NSMutableAttributedString, size : CGSize, keyDic : [String : UIColor]) {
        contentLabel?.width = size.width - 10;
        contentLabel?.height = size.height;
        
        contentLabel?.attributedText = content;
        topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y)
    }
}
