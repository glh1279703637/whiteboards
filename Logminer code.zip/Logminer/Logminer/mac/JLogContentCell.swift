//
//  JLogContentCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit
typealias kSelectDateCallback = ((_ string : String) -> ())

class JLogContentCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    var topImageView : UIImageView?
    var syncButton : UIButton?
    internal var m_selectCallback : kSelectDateCallback?

    var isCellBackgroudColor = 0 { // 多种类型数据
        willSet {
            if newValue == 1 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.2, green: 0, blue: 0, alpha: 0.1)
            } else if newValue == 2 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
            } else if newValue == 3 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
            } else {
                self.contentLabel?.backgroundColor = nil
            }
        }
    }

    override func funj_addBaseTableSubView() {
        topImageView = UIImageView(i: CGRect(x: 0, y: 0, width: 20, height: 20), image: "star")
        topImageView?.contentMode = .scaleAspectFit
        syncButton = UIButton(i: CGRect(x: 0, y: 3, width: 20, height: 20) , title: "", textFC: JTextFC())
            .funj_add(bgImageOrColor: ["course_copy_n"], isImage: true)
            .funj_addblock(block: { [weak self] button in
            if let string = self?.contentLabel?.attributedText.string  as? NSString {
                var start = string.range(of: ". 2")
                var indexd = 0;
                if(start.length == 0) {
                    indexd = 1
                    start = string.range(of: ". [2")
                }
                if(start.length > 0) {
                    let ss = string.substring(with: NSRange(location: start.location+2+indexd, length: 19))
                    self?.m_selectCallback?(ss as String)
                }
            }
        })
        syncButton!.addSubview(topImageView!)

        
        self.clipsToBounds = true
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 0, height: 0), textFC: JTextFC(f: kFont_Size15, c: kColor_Text_Black, a:.center))
        contentLabel?.isEditable = false
        contentLabel?.textContainerInset = .zero
        contentLabel?.isScrollEnabled = false;
        self.contentView.addSubview(contentLabel!)
        self.contentView.addSubview(syncButton!)
    }
    func setCellContent(content : NSMutableAttributedString, size : CGSize, keyDic : [String : UIColor]) {
        contentLabel?.width = size.width - 10;
        contentLabel?.height = size.height;
        syncButton?.height = size.height - 6;
        
        contentLabel?.attributedText = content;
        
        let width = content.boundingRect(with: CGSize(width: size.width * 2, height: 20), options: .usesLineFragmentOrigin, context: nil).width
        if width > size.width {
            contentLabel?.textContainerInset = .zero
            topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y + 2)
        } else {
            contentLabel?.textContainerInset = UIEdgeInsets(top: 10, left: 0, bottom: 0, right: 0)
            topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y)
        }
    }
}
