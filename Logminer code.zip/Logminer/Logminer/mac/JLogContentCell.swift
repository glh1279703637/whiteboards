//
//  JLogContentCell.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentCell : JBaseTableViewCell {
    var contentLabel : UITextView?
    var topImageView : UIImageView?
    var isCellBackgroudColor = 0 { // 多种类型数据
        willSet {
            if newValue == 1 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.2, green: 0, blue: 0, alpha: 0.1)
            } else if newValue == 2 {
                self.contentLabel?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
            } else {
                self.contentLabel?.backgroundColor = nil
            }
        }
    }

    override func funj_addBaseTableSubView() {
        topImageView = UIImageView(i: CGRect(x: 0, y: 0, width: 20, height: 20), image: "star")
        self.contentView.addSubview(topImageView!)
        topImageView?.contentMode = .scaleAspectFit
        
        self.clipsToBounds = true
        contentLabel = UITextView(i: CGRect(x: 10, y: 0, width: 0, height: 0), textFC: JTextFC(f: kFont_Size15, c: kColor_Text_Black, a:.center))
        contentLabel?.isEditable = false
        contentLabel?.textContainerInset = .zero
        contentLabel?.isScrollEnabled = false;
        self.contentView.addSubview(contentLabel!)
    }
    func setCellContent(content : NSMutableAttributedString, size : CGSize, keyDic : [String : UIColor]) {
        contentLabel?.width = size.width - 10;
        contentLabel?.height = size.height;
        
        contentLabel?.attributedText = content;
        
        let width = content.boundingRect(with: CGSize(width: size.width * 2, height: 20), options: .usesLineFragmentOrigin, context: nil).width
        if width > size.width {
            contentLabel?.textContainerInset = .zero
            topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y + 2)
        } else {
            contentLabel?.textContainerInset = UIEdgeInsets(top: 10, left: 0, bottom: 0, right: 0)
            topImageView?.center = CGPoint(x: topImageView!.center.x, y: contentLabel!.center.y)
        }
    }
}
