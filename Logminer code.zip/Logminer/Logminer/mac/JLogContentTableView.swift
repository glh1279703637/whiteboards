//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    var m_dataArray : [[String]] = []
    var m_dataArr : [[String]] = []
    var keyDic : [String : UIColor] = [:]
    var m_saveMatchColorDic : [String : UIColor] = [ : ]
    var saveMainBgDic : [String : UIColor] = [:]
    var saveKeyAlignDic : [String : Int] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    var m_prefixTF4 : UITextField?
    var m_prefixTF5 : UITextField?
    var m_searchfixTF2 : UITextField?
    var m_searchCountLabel : UILabel?

    var m_startDate1 : String = ""
    var m_endDate1 : String = ""
    var m_searchIndexPath : IndexPath = IndexPath(row: 0, section: 0)
    var m_searchIndexPathFromScroll = false
    var m_savePath : String = ""
    var m_totalCount = 0
    
    var itemSelectView : JItemSelectView?
    var m_splitScreenBt : UIButton?
    var m_copyContentBt : UIButton?
    var m_saveContentBt : UIButton?
    var m_saveOnlyContentBt : UIButton?
    var m_showDrawBt : UIButton?
    var m_saveLineBt : UIButton?
    var m_splitTopPoint : CGFloat = kStatusBarHeight + 30
    var m_saveAttriDic : [String : NSMutableAttributedString] = [:]
    var m_saveMatchKeyDic : [String : Int] = [:]
    var m_selectRowTitle : String?

    var m_subDeleteStrDic : [Int : Int] = [:]
    var topSectionHeigh = 20
    var topCellHeigh : CGFloat = 35
    
    var bgImageView : UIImageView?
    var m_shapeLayer : CAShapeLayer?
    var m_penDrawView : JMainPenDrawView?
    var m_addIndex : Int = 0

    internal var m_selectRowCallback : kSelectDateCallback?


    lazy var m_tableView : UITableView = {
        let tableView =  kcreateTableViewWithDelegate(self)
        return tableView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        bgImageView = UIImageView(i: CGRect(x: 0, y: 0, width: 0, height: 20), image: nil)
        self.addSubview(bgImageView!)
        
        self.addSubview(self.m_tableView)
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.showsVerticalScrollIndicator = true
        
        m_penDrawView = JMainPenDrawView(frame: CGRect(x: 0, y: 0, width: self.width, height: self.height));
        m_penDrawView?.isUserInteractionEnabled = false
        self.addSubview(m_penDrawView!)
        
        itemSelectView = JItemSelectView()
        itemSelectView!.view.frame = CGRect(x: 80, y: 0, width: self.width - 150, height: 20)
        self.addSubview(itemSelectView!.view)
        itemSelectView?.m_selectCallback = { [weak self] (section) in
            let indexpath = IndexPath(row: 0, section: section )
            self?.m_tableView.scrollToRow(at: indexpath, at: .top, animated: true)
        }
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 15), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
        
        m_searchfixTF2 = JLogContentTableView.funj_getTextField("", "搜索定位")
        m_searchfixTF2?.width = 300
        m_searchfixTF2?.delegate = self
        self.addSubview(m_searchfixTF2!)
        m_searchfixTF2?.leftViewMode = .always
        m_searchfixTF2?.leftView = self.funj_getTextLeftView("向上")
        m_searchfixTF2?.rightViewMode = .always
        m_searchfixTF2?.rightView = self.funj_getTextLeftView("向下")
        m_searchCountLabel = UILabel(i: CGRect(x: m_searchfixTF2!.width - 40 - 40 , y: 0, width: 40, height: 20), title: "", textFC: JTextFC(f: kFont_Size14, c: kColor_Blue, a:.right))
        m_searchCountLabel?.adjustsFontSizeToFitWidth = true
        m_searchfixTF2?.addSubview(m_searchCountLabel!)

        m_saveContentBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "写入", callback: { [weak self] button in
            var string = ""
            for array in self?.m_dataArr ?? [] {
                string += array.joined(separator: "\n")
                string += "\n"
            }
            try? (string as? NSString)?.write(toFile: self!.m_savePath + ".txt", atomically: true, encoding: String.Encoding.utf8.rawValue)
        })
        m_copyContentBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "复制", callback: { [weak self] button in
            var string = ""
            for array in self?.m_dataArr ?? [] {
                string += array.joined(separator: "\n")
            }
            UIPasteboard.general.string = string
        })
        m_saveLineBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "加宽", callback: { [weak self] button in
            self?.topCellHeigh += 20
            self?.m_tableView.reloadData()
            self?.funj_reloadToMatchValue()
        })
        m_saveOnlyContentBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "仅显示", callback: { [weak self] button in
            self?.m_isOnlyShowInfo = !self!.m_isOnlyShowInfo
            self?.funj_reloadData()
        })
        m_showDrawBt = funj_getButton(CGRect(x: self.width - 10, y: 0, width: 40, height: 20), title: "画笔", callback: { [weak self] button in
            self?.m_penDrawView?.isUserInteractionEnabled = !self!.m_penDrawView!.isUserInteractionEnabled
            self!.m_penDrawView?.height = self!.m_tableView.contentSize.height
            self!.m_penDrawView?.width = self!.m_tableView.width
        })
        let stringlength = UserDefaults.standard.string(forKey: "subStringRangeLength") ?? "26:20"
        m_prefixTF4 = JLogContentTableView.funj_getTextField(stringlength, "减短(26:20)")
        m_prefixTF4?.delegate = self
        self.addSubview(m_prefixTF4!)
        m_prefixTF5 = JLogContentTableView.funj_getTextField("", "锁定 section序号 或者 开始/结束时间段")
        m_prefixTF5?.width = 300
        m_prefixTF5?.delegate = self
        self.addSubview(m_prefixTF5!)

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        self.funj_addCornerLayer(JFilletValue(w: 1, r: 3, c: kColor_Red))
        m_prefixTF = JLogContentTableView.funj_getTextField("23", "排序字母数")
        m_prefixTF1 = JLogContentTableView.funj_getTextField(",", "替换字")
        m_prefixTF2 = JLogContentTableView.funj_getTextField(".", "被替换字")
        self.addSubview(m_prefixTF!)
        self.addSubview(m_prefixTF1!)
        self.addSubview(m_prefixTF2!)
        
        m_splitScreenBt = funj_getButton(CGRect(x: self.width - 90, y: 0, width: 40, height: 20), title: "半屏", callback: { [weak self] button in
            self?.m_splitTopPoint = (self?.m_splitTopPoint ?? 0) > kStatusBarHeight + 30 ? kStatusBarHeight + 30 : (self?.height ?? 0) / 2
            self?.top = self?.m_splitTopPoint ?? 0
            self?.height = (self?.height ?? 0) - (self?.top ?? 0)
        })
    }
    static func funj_getTextField(_ title : String, _ place : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x:50, y: 30, width: 50, height: 20), placeholder: place, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.autocorrectionType = .no
        prefixTF.text = title
        return prefixTF
    }
    func funj_getButton(_ frame : CGRect, title : String, callback :kclickCallBack?) -> UIButton {
        let button = UIButton(i: frame, title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_White)).funj_add(bgImageOrColor: [kColor_Orange], isImage: false)
            .funj_addblock(block: callback)
        self.addSubview(button)
        return button
    }
    func funj_getTextLeftView(_ title : String) -> UIView {
        let view = UIView(i: CGRect(x: 0, y: 0, width: 40, height: 20), bg: kColor_Orange)
        let button = UIButton(i: CGRect(x: 0, y: 0, width: 40, height: 20), title: title, textFC: JTextFC(f: kFont_Size13, c: kColor_White))
            .funj_addblock { [weak self] button in
                if button.titleLabel?.text == "向上" {
                    self?.funj_searchContent(true)
                } else {
                    self?.funj_searchContent(false)
                }
            }
        view.addSubview(button)
        return view
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == m_prefixTF4 {
            if textField.text!.count > 0 {
                UserDefaults.standard.set(textField.text, forKey: "subStringRangeLength")
                UserDefaults.standard.synchronize()
            }
            self.funj_reloadData()
        } else if textField == m_prefixTF5 {
            self.funj_reloadData()
        } else if textField == m_searchfixTF2 {
            if m_searchfixTF2?.text?.count ?? 0 <= 0 {
                self.m_tableView.reloadData()
                return
            }
            var selectIndex : IndexPath?
            let beginIndex : IndexPath = self.m_searchIndexPath
             m_totalCount = 0
             var m_currentCount = 0
            var section = 0
            var first = false
            for array in self.m_dataArr {
                if section > beginIndex.section - 1 {
                    first = true
                }
                var row = 0
                var secord = false
                for str in array {
                    if row > beginIndex.row - 1 {
                        secord = true
                    }
                    if str.lowercased().contains(textField.text!.lowercased()) {
                        m_totalCount += 1
                        if first && secord && selectIndex == nil {
                            m_currentCount = m_totalCount
                            selectIndex = IndexPath(row: row , section: section)
                        }
                    }
                    row += 1
                }
                section += 1
            }
            if selectIndex != nil {
                self.m_searchIndexPath = selectIndex!
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    if self.m_searchIndexPath.section >= self.m_dataArr.count || self.m_searchIndexPath.row >= self.m_dataArr[self.m_searchIndexPath.section].count { return }
                    self.m_searchCountLabel?.text = "\(m_currentCount)/\(self.m_totalCount)"
                    self.m_tableView.scrollToRow(at: self.m_searchIndexPath, at: .top, animated: false)
                    self.m_tableView.reloadData()
                }
            }
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_tableView.frame = self.bounds
        for cell in self.m_tableView.visibleCells as! [JLogContentCell]{
            cell.contentLabel!.width = self.m_tableView.width - 10;
        }
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 20;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 20;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 20;
        m_prefixTF4?.left = self.width - 70;
        m_prefixTF4?.top = self.height - 40;
        m_prefixTF5?.left = self.width - 70 - m_prefixTF5!.width;
        m_prefixTF5?.top = self.height - 40;

        if self.titleLabel?.text == "Main" {
            m_searchfixTF2?.left = m_prefixTF!.left - m_searchfixTF2!.width;
        } else {
            if (self.superview?.superview?.frame.origin.x ?? 0) + self.frame.size.width < (self.superview?.superview?.superview?.width ?? 0) - 10 {
                m_searchfixTF2?.left = 0;
            } else {
                m_searchfixTF2?.left = self.width - 360 - m_searchfixTF2!.width;
            }
        }
        m_searchfixTF2?.top = self.height - 20;
        self.itemSelectView?.view.width = self.width - titleLabel!.width - 120
        self.itemSelectView?.view.left = 90
        m_splitScreenBt?.left = self.width - 90
        let array = [m_saveLineBt,m_copyContentBt,m_saveContentBt,m_saveOnlyContentBt,m_showDrawBt]
        var left = self.width - 10
        for button in array {
            button!.left = left - 45
            button!.top = self.height - 70
            left = button!.left
        }
        self.m_penDrawView?.height = self.m_tableView.contentSize.height
        self.m_penDrawView?.width = self.m_tableView.width
        itemSelectView!.view.frame = CGRect(x: 80, y: 0, width: self.width - 150, height: 20)
    }
    func funj_reloadButton() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.itemSelectView?.m_dataArr.removeAll()
            for index in 0..<self.m_dataArr.count {
                self.itemSelectView?.m_dataArr.append("\(index + 1)")
            }
            self.itemSelectView?.funj_reloadData()
        }
    }
    func funj_reloadToMatchValue() {
        self.funj_reloadData()
        self.bgImageView?.width = self.width
        self.bgImageView?.height = self.m_tableView.contentSize.height
        m_shapeLayer?.removeFromSuperlayer()
        m_shapeLayer = CAShapeLayer()
        self.bgImageView?.layer.addSublayer(m_shapeLayer!)
        m_shapeLayer?.frame = self.bgImageView!.bounds
        self.m_saveMatchKeyDic.removeAll()
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            var isConnect = false
            for (key, color) in self.m_saveMatchColorDic {
                let split = (key as NSString).range(of: "<>").length > 0 ? "<>" : "<~>"
                let array = key.components(separatedBy: split)
                isConnect = split == "<~>" ? true : false
                
                let shapeLayer = CAShapeLayer()
                shapeLayer.strokeColor = color.cgColor
                shapeLayer.fillColor = nil
                shapeLayer.lineWidth = 3
                self.m_shapeLayer?.addSublayer(shapeLayer)

                let rootPath = UIBezierPath()
                let total = self.m_dataArr.count
                var top = 0
                for inde in 0..<total { // session
                    let count = self.m_dataArr[inde].count
                    top += self.topSectionHeigh
                    if inde > 0 {
                        top += self.m_dataArr[inde - 1].count * Int(self.topCellHeigh)
                    }
                    var indexfd = 0
                    var upIndex = 0
                    var left2 = 0
                    var isHasOnly = true
                    for index in 0..<count {
                        let string = self.m_dataArr[inde][index]
                        if isConnect {
                            for key1 in array {
                                let first = key1.lowercased()
                                if string.lowercased().contains(first) {
                                    indexfd += 1
                                    if indexfd > 1 {
                                        isHasOnly = false
                                        left2 = self.funj_addMatchLine(top, left2 ,start: upIndex, end: index, color: color, rootPath: rootPath, key : first, index : indexfd)
                                    }
                                    upIndex = index;
                                }
                            }
                        } else {
                            if indexfd >= array.count && indexfd > 0 {
                                indexfd = 0;
                            }
                            let first = array[indexfd].lowercased()
                            if string.lowercased().contains(first) {
                                indexfd += 1
                                if(indexfd > 1) {
                                    isHasOnly = false
                                    left2 = self.funj_addMatchLine(top, left2 ,start: upIndex, end: index, color: color, rootPath: rootPath, key : first, index : indexfd)
                                }
                                upIndex = index;
                            }
                        }
                    }
                    if isHasOnly {
                        self.funj_addNoMatchLine(top, start: upIndex, color: color, rootPath: rootPath, key : array.first ?? "")
                    }
                }
                shapeLayer.path = rootPath.cgPath
            }
        }
        
    }
    func funj_addMatchLine(_ top : Int, _ left2 : Int, start : Int, end : Int, color : UIColor, rootPath : UIBezierPath, key : String, index : Int) -> Int {
        let path = UIBezierPath()
        let startPoint = top + (start + 1) * Int(self.topCellHeigh) - Int(self.topCellHeigh - 5)
        let endPoint = top + (end + 1) * Int(self.topCellHeigh) - 5
        let keyd = "\(end)-\(key)"
        var left = self.m_saveMatchKeyDic[keyd];
        if left == nil {
            left = Int(arc4random() % 200) + 10
        }
        left! += 6
        if left2 > 0 {
            left = left2
        }
        self.m_saveMatchKeyDic[keyd] = left

        path.move(to: CGPoint(x: left! + 30, y: startPoint))
        path.addLine(to: CGPoint(x: left!, y: startPoint))
        path.addLine(to: CGPoint(x: left!, y: endPoint))
        path.addLine(to: CGPoint(x: left! + 30, y: endPoint))
        rootPath.append(path)
        return left!
    }
    func funj_addNoMatchLine(_ top : Int, start : Int, color : UIColor, rootPath : UIBezierPath, key : String) {
        let path = UIBezierPath()
        let startPoint = top + (start + 1) * Int(self.topCellHeigh) - 5

        path.move(to: CGPoint(x: 30, y: startPoint))
        path.addLine(to: CGPoint(x: Int(self.m_tableView.width) - 60, y: startPoint))
        rootPath.append(path)
    }
    func funj_reloadData() {
        var session = 0
        var dataArray : [[String]] = []
        
        if let array = self.m_prefixTF4!.text?.components(separatedBy: ";") {
            self.m_subDeleteStrDic.removeAll()
            for str in array {
                if let array1 = str.components(separatedBy: ":") as? [String] {
                    let firstdelete = Int(array1.first ?? "0") ?? 0
                    let subdelete = Int(array1.last ?? "0") ?? 0
                    self.m_subDeleteStrDic[firstdelete] = subdelete
                }
            }
        }
        var lockIndex = 0
        var firstDate : String?
        var lastDate : String?
        var startLength = 0
        var endLength = 0
        if let lockStr = self.m_prefixTF5?.text {
            lockIndex = Int(lockStr) ?? 0
            if lockStr.contains("/") && lockIndex == 0 {
                let array = lockStr.components(separatedBy: "/")
                firstDate = array.first
                lastDate = array.last
                startLength = firstDate!.count
                endLength = lastDate!.count
            }
            if startLength <= 0 || endLength <= 0 { // 防止写过程中变化
                firstDate = nil
                lastDate = nil
                startLength = 0
                endLength = 0
            }
        }
        self.itemSelectView?.view?.isHidden = lockIndex > 0
        self.m_shapeLayer?.removeFromSuperlayer()
        
        var measurements = [1.2, 1.5, 2.9, 1.2, 1.5]
        measurements.removeSubrange(1..<4)
        
        for (keys, color) in self.m_saveMatchColorDic {
            let split = (keys as NSString).range(of: "<>").length > 0 ? "<>" : "<~>"
            let array = keys.components(separatedBy: split)
            for key in array {
                if self.keyDic[key] == nil {
                    self.keyDic[key] = color
                }
            }
        }
        var isstart = false
        var isend = true
        for array in self.m_dataArray {
            var dataArr : [String] = []
            var sessionRow = 0
            session += 1
            if(lockIndex > 0 && session != lockIndex) {
                continue
            }
            for var string in array as [String] {
                if string.hasPrefix("[20") == true{
                    let start = (string as NSString).range(of: "[")
                    string = (string as NSString).substring(from: 1)
                }
                if startLength > 0 && endLength > 0 {
                    let contentLenght = string.count
                    if startLength > 0 && contentLenght >= startLength {
                        let key11 = (string as NSString).substring(to: startLength)
                        if key11 < firstDate! {
                            continue
                        }
                        isstart = true
                    } else if(!isstart) {
                        continue
                    }
                    if endLength > 0 && contentLenght >= endLength {
                        let key11 = (string as NSString).substring(to: endLength)
                        if key11 > lastDate! {
                            isend = false
                            continue
                        }
                        isend = true
                    } else if !isend {
                        continue
                    }
                }
                
                if m_isOnlyShowInfo {
                    var isHas = false
                    for (key,_) in self.keyDic {
                        if string.lowercased().contains(key.lowercased()) {
                            isHas = true;break
                        }
                    }
                    if isHas {
                        dataArr.append(string)
                        sessionRow += 1
                    }
                } else {
                    dataArr.append(string)
                    sessionRow += 1
                }
            }
            for _ in 0..<3 {
                dataArr.append("")
            }
            dataArray.append(dataArr)
            
        }
        self.m_dataArr.removeAll()
        self.m_dataArr += dataArray
         
        self.m_saveAttriDic.removeAll()
        
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            self.m_tableView.reloadData()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                if let cell = self.m_tableView.cellForRow(at: IndexPath(row: 0, section: 0)) {
                    self.topSectionHeigh = Int(cell.top)
                }
            }
        }
        self.layoutSubviews()
    }
    func funj_updateToScrollCell(_ date : String) {
        if date.count <= 0 || self.m_dataArr.count <= 0 { return }
        self.m_selectRowTitle = date
        var selectIndex : IndexPath?
        var section = 0;
        var isbreak = false
        for array in self.m_dataArr {
            var row = 0;
            for var str in array {
                if  str.hasPrefix("[") == true{
                    let start = (str as NSString).range(of: "[")
                    str = (str as NSString).substring(from: 1)
                }
                if str.lowercased() >= date.lowercased() {
                    if str.hasPrefix(date.substring(to: date.index(date.startIndex, offsetBy: 4))) {
                        isbreak = true
                        selectIndex = IndexPath(row: row , section: section)
                        break
                    }
                }
                row += 1
            }
            if isbreak { break; }
            section += 1
        }
        if selectIndex == nil {
            selectIndex = IndexPath(row: self.m_dataArr.last!.count - 1, section: self.m_dataArr.count - 1)
        }
        self.m_searchIndexPath = selectIndex!
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            if self.m_searchIndexPath.section >= self.m_dataArr.count || self.m_searchIndexPath.row >= self.m_dataArr[self.m_searchIndexPath.section].count { return }
            self.m_tableView.scrollToRow(at: self.m_searchIndexPath, at: .middle, animated: false)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                if self.m_searchIndexPath.section >= self.m_dataArr.count || self.m_searchIndexPath.row >= self.m_dataArr[self.m_searchIndexPath.section].count { return }
                let cell = self.m_tableView.cellForRow(at: self.m_searchIndexPath) as! JLogContentCell
                cell.isCellBackgroudColor = 3
            }
        }
    }
    func funj_searchContent(_ isUp : Bool, _ isend : Bool = false) {
        let textField = self.m_searchfixTF2!
        if textField.text!.count <= 0 {
            return
        }
        var section = 0; var row = 0;
        var upsearchIndexPath : IndexPath?
        var nextsearchIndexPath : IndexPath?
        var isHas = false
        var countIndex = 0
        
        for array in self.m_dataArr {
            section += 1
            row = 0;
            for str in array {
                row += 1
                if str.lowercased().contains(textField.text!.lowercased()) {
                    let index = IndexPath(row: row - 1 , section: section - 1)
                    if m_searchIndexPath > index {
                        upsearchIndexPath = index
                        countIndex += 1
                    } else if index > m_searchIndexPath {
                        nextsearchIndexPath = index
                        isHas = true
                        break
                    }
                }
            }
            if isHas {
                break
            }
        }
        if isUp {
            if upsearchIndexPath == nil {
                m_searchIndexPath = IndexPath(row:self.m_dataArr.last?.count ?? 0 , section:  self.m_dataArr.count - 1)
                if !isend {
                    self.funj_searchContent(isUp, true)
                }
                return
            }
            m_searchIndexPath = upsearchIndexPath!
        } else {
            if nextsearchIndexPath == nil {
                m_searchIndexPath = IndexPath(row: 0, section: 0)
                if !isend {
                    self.funj_searchContent(isUp, true)
                }
                return
            }
            countIndex += 2
            m_searchIndexPath = nextsearchIndexPath!
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            if self.m_searchIndexPath.section >= self.m_dataArr.count || self.m_searchIndexPath.row >= self.m_dataArr[self.m_searchIndexPath.section].count { return }
            self.m_searchCountLabel?.text = "\(countIndex)/\(self.m_totalCount)"
            self.m_tableView.scrollToRow(at: self.m_searchIndexPath, at: .middle, animated: false)
            let cell = self.m_tableView.cellForRow(at: self.m_searchIndexPath) as? JLogContentCell
            cell?.isCellBackgroudColor = 2
        }
    }
}
extension JLogContentTableView {
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.m_dataArr.count
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "NO. \(section + 1)"
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.m_dataArr[section].count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.topCellHeigh
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        if(indexPath.section >= self.m_dataArr.count || indexPath.row >= self.m_dataArr[indexPath.section].count) {
            return tableviewCell
        }
        tableviewCell.m_selectCallback = self.m_selectRowCallback
        tableviewCell.m_selectCallback2 = { [weak self] (title) in
            self?.m_addIndex += 1
            let button = UIButton(i: CGRect(x: self!.m_addIndex * 22, y: 30, width: 20, height: 20), title: "\(self!.m_addIndex)", textFC: JTextFC(f: kFont_Size10, c: kColor_White)).funj_add(targe: self!, action: "selectItemToScroll:", tag: 0).funj_add(bgImageOrColor: [kColor_Orange], isImage: false).funj_addCornerLayer(JFilletValue(w: 0, r: 10, c: kColor_Orange))
            button.titleLabel?.adjustsFontSizeToFitWidth = true
            button.accessibilityValue = title
            self?.addSubview(button)
        }
        var string1 = self.m_dataArr[indexPath.section][indexPath.row]
        if self.m_subDeleteStrDic.count > 0 {
            for (m_firstdelete, m_subdelete) in self.m_subDeleteStrDic {
                if m_firstdelete + m_subdelete < string1.count  && m_subdelete > 0 {
                    let start = string1.index(string1.startIndex, offsetBy: m_firstdelete)
                    let end = string1.index(start, offsetBy: m_subdelete)
                    string1.replaceSubrange(start..<end, with: " ")
                }
            }
        }

        let content = "\(indexPath.row). " + string1
        var string : NSMutableAttributedString? = self.m_saveAttriDic[content]
        if string == nil {
            let param = NSMutableParagraphStyle()
            param.lineSpacing = -4
            string = NSMutableAttributedString(string: content , attributes: [.font : kFont_Size15, .paragraphStyle : param]);
            for (key, value) in keyDic {
                let range = (content.lowercased() as NSString).range(of: key.lowercased());
                if range.length > 0 {
                    string?.addAttributes([.backgroundColor : value, .font : kFont_Size16], range: range);
                }
            }
            self.m_saveAttriDic[content] = string
        }
        if (self.m_searchfixTF2?.text?.count ?? 0) > 0 && content.lowercased().contains(self.m_searchfixTF2!.text!.lowercased()) {
            tableviewCell.isCellBackgroudColor = 1
        } else if(self.m_selectRowTitle?.count ?? 0) > 0 && content.lowercased().contains(self.m_selectRowTitle!.lowercased())  {
            tableviewCell.isCellBackgroudColor = 3
        } else {
            tableviewCell.isCellBackgroudColor = 0
        }
        if(self.m_searchIndexPath.section == indexPath.section && self.m_searchIndexPath.row == indexPath.row)  && self.m_searchIndexPathFromScroll == false && self.m_searchfixTF2!.text!.count > 0 {
           tableviewCell.isCellBackgroudColor = 2
        }
        self.m_searchIndexPathFromScroll = false
        
        tableviewCell.setCellContent(content: string!, size: NSMakeSize(self.m_tableView.width, self.topCellHeigh), keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArr[indexPath.section][indexPath.row]]
        var isHidden = true
        let contentLenght = string1.count;
        let startLength = self.m_startDate1.count;
        let endLength = self.m_endDate1.count;

        if startLength > 0 && contentLenght >= startLength {
            let key11 = (string1 as NSString).substring(to: startLength) as! String
            if key11 >= self.m_startDate1 {
                isHidden = false
            }
        }
        if endLength > 0 && contentLenght >= endLength {
            let key11 = (string1 as NSString).substring(to: endLength) as! String
            if key11 > self.m_endDate1 {
                isHidden = true
            }
        }
        tableviewCell.topImageView?.isHidden = isHidden
        
        if(self.saveKeyAlignDic.count > 0) {
            var value2 = 0
            for (key, value) in self.saveKeyAlignDic {
                let range = (content.lowercased() as NSString).range(of: key.lowercased());
                if range.length > 0 {
                    value2 = value
                    break
                }
            }
            tableviewCell.addLeft = value2 * 100
        }
        return tableviewCell
    }
    @objc func selectItemToScroll(_ sender : UIButton) {
        self.funj_updateToScrollCell(sender.accessibilityValue!)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == self.m_tableView {
            let top = scrollView.contentOffset.y
            bgImageView?.top = -top
            self.m_penDrawView?.top = -top
            
            if scrollView.isDragging && scrollView.isTracking && !scrollView.isDecelerating {
                self.scrollViewDidEndDecelerating(scrollView)
            }
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if let indexPath = self.m_tableView.indexPathsForVisibleRows?.first {
            if self.m_searchfixTF2?.text?.count ?? 0 > 0 {
                self.m_searchIndexPathFromScroll = true
                self.m_searchIndexPath = indexPath
            }
        }
    }
    
}

