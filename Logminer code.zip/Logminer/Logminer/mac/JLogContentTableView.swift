//
//  JLogContentTableView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/11/25.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JLogContentTableView : UIView, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    var m_dataArray : [[String]] = []
    var keyDic : [String : UIColor] = [:]
    var saveKeyHeight : [String : CGFloat] = [:]
    var saveMainBgDic : [String : UIColor] = [:]
    var titleLabel : UILabel?
    var m_isOnlyShowInfo = false
    var m_prefixTF : UITextField?
    var m_prefixTF1 : UITextField?
    var m_prefixTF2 : UITextField?
    var m_searchfixTF2 : UITextField?

    var m_startDate1 : String = ""
    var m_endDate1 : String = ""
    var m_searchIndexPath : IndexPath = IndexPath(row: 0, section: 0)
    
    var m_bgScrollView : UIScrollView?

    lazy var m_tableView : UITableView = {
        let tableView =  kcreateTableViewWithDelegate(self)
        return tableView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.m_tableView)
        self.m_tableView.register(JLogContentCell.self, forCellReuseIdentifier: kCellIndentifier)
        
        m_bgScrollView = UIScrollView(frame: CGRect(x: 80, y: 0, width: self.width - 150, height: 30))
        self.addSubview(m_bgScrollView!)
        
        titleLabel = UILabel(i: CGRect(x: 0, y: 0, width: 30, height: 20), bg: kColor_Bg_Shallow_Lightgray)
        titleLabel?.textAlignment = .right
        titleLabel?.textColor = krandomColor
        self.addSubview(titleLabel!);
        
        m_searchfixTF2 = JLogContentTableView.funj_getTextField("", "搜索定位")
        m_searchfixTF2?.width = 300
        self.addSubview(m_searchfixTF2!)
        m_searchfixTF2?.leftViewMode = .always
        m_searchfixTF2?.leftView = self.funj_getTextLeftView("向上")
        m_searchfixTF2?.rightViewMode = .always
        m_searchfixTF2?.rightView = self.funj_getTextLeftView("向下")
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func funj_reloadMainContentView() {
        m_prefixTF = JLogContentTableView.funj_getTextField("23", "排序字母数")
        m_prefixTF1 = JLogContentTableView.funj_getTextField(",", "替换字")
        m_prefixTF2 = JLogContentTableView.funj_getTextField(".", "被替换字")
        self.addSubview(m_prefixTF!)
        self.addSubview(m_prefixTF1!)
        self.addSubview(m_prefixTF2!)
    }
    static func funj_getTextField(_ title : String, _ place : String) ->UITextField {
        let prefixTF = UITextField(i: CGRect(x:50, y: 30, width: 50, height: 30), placeholder: place, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_addCornerLayer(JFilletValue(w: 1, r: 2, c: kColor_White))
        prefixTF.backgroundColor = kColor_Orange
        prefixTF.autocorrectionType = .no
        prefixTF.text = title
        return prefixTF
    }
    func funj_getTextLeftView(_ title : String) -> UIView {
        let view = UIView(i: CGRect(x: 0, y: 0, width: 40, height: 30), bg: kColor_Orange)
        let button = UIButton(i: CGRect(x: 0, y: 0, width: 40, height: 30), title: title, textFC: JTextFC(f: kFont_Size10, c: kColor_White))
            .funj_addblock { [weak self] button in
                if button.titleLabel?.text == "向上" {
                    self?.funj_searchContent(true)
                } else {
                    self?.funj_searchContent(false)
                }
            }
        view.addSubview(button)
        return view
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        let width = self.m_tableView.width
        self.m_tableView.frame = self.bounds
        if width != self.m_tableView.frame.size.width {
            self.saveKeyHeight.removeAll()
        }
        self.m_tableView.reloadData()
        titleLabel?.width = JAppUtility.funj_getTextWidthWithView(titleLabel!)
        titleLabel?.left = self.width - titleLabel!.width - 20;
        
        m_prefixTF?.left = self.width - 150;
        m_prefixTF?.top = self.height - 30;
        m_prefixTF1?.left = self.width - 100;
        m_prefixTF1?.top = self.height - 30;
        m_prefixTF2?.left = self.width - 50;
        m_prefixTF2?.top = self.height - 30;
        if self.titleLabel?.text != "Main" {
            m_searchfixTF2?.left = self.width - 360 - m_searchfixTF2!.width;
        } else {
            m_searchfixTF2?.left = m_prefixTF!.left - m_searchfixTF2!.width;
        }
        m_searchfixTF2?.top = self.height - 30;
        self.m_bgScrollView?.width = self.width - titleLabel!.width - 120
        self.m_bgScrollView?.left = 90
    }
    func funj_reloadButton() {
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            for view in self.m_bgScrollView!.subviews {
                if view.tag >= 2000000 {
                    view.removeFromSuperview()
                }
            }
            for i in 0..<self.m_dataArray.count {
                let button = UIButton(i: CGRect(x: i * 60, y: 5, width: 56, height: 20), title: "NO.\(i + 1)", textFC: JTextFC(f: kFont_Size12, c: kColor_White))
                    .funj_addblock { [weak self] button in
                        let indexpath = IndexPath(row: 0, section: button.tag - 2000000)
                        self?.m_tableView.scrollToRow(at: indexpath, at: .top, animated: true)
                    }
                button.tag = 2000000 + i
                button.backgroundColor = kColor_Orange
                self.m_bgScrollView!.addSubview(button)
            }
            self.m_bgScrollView?.contentSize = CGSize(width: self.m_dataArray.count * 60 + 50, height: 0)
        }
    }
    func funj_reloadData() {
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            self.m_tableView.reloadData()
        }
    }
    func funj_searchContent(_ isUp : Bool, _ isend : Bool = false) {
        let textField = self.m_searchfixTF2!
        if textField.text!.count <= 0 {
            return
        }
        var section = 0; var row = 0;
        var upsearchIndexPath : IndexPath?
        var nextsearchIndexPath : IndexPath?
        var isHas = false
        for array in self.m_dataArray {
            section += 1
            row = 0;
            for str in array {
                row += 1
                if str.contains(textField.text!) {
                    let index = IndexPath(row: row - 1 , section: section - 1)
                    if m_searchIndexPath > index {
                        upsearchIndexPath = index
                    } else if index > m_searchIndexPath {
                        nextsearchIndexPath = index
                        isHas = true
                        break
                    }
                }
            }
            if isHas {
                break
            }
        }
        if isUp {
            if upsearchIndexPath == nil {
                m_searchIndexPath = IndexPath(row:self.m_dataArray.last?.count ?? 0 , section:  self.m_dataArray.count - 1)
                if !isend {
                    self.funj_searchContent(isUp, true)
                }
                return
            }
            m_searchIndexPath = upsearchIndexPath!
        } else {
            if nextsearchIndexPath == nil {
                m_searchIndexPath = IndexPath(row: 0, section: 0)
                if !isend {
                    self.funj_searchContent(isUp, true)
                }
                return
            }
            m_searchIndexPath = nextsearchIndexPath!
        }
        self.m_tableView.scrollToRow(at: m_searchIndexPath, at: .middle, animated: false)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            let cell = self.m_tableView.cellForRow(at: self.m_searchIndexPath)
            cell?.backgroundColor = kRGB(red: 0.3, green: 0, blue: 0, alpha: 0.2)
        }
    }
}
extension JLogContentTableView {
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.m_dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30;
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "NO. \(section + 1)"
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.m_dataArray[section].count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let string = self.m_dataArray[indexPath.section][indexPath.row]
        if m_isOnlyShowInfo {
            var isHas = false
            for (key,_) in self.keyDic {
                if string.contains(key) {
                    isHas = true;
                }
            }
            if isHas == false {
                return 0
            }
        }
        if let height = self.saveKeyHeight[string] {
            return height
        }

        let size = JAppUtility.funj_getTextW_Height(string as String, textFont: kFont_Size15, layoutwidth: self.width - 20, layoutheight: 500)
        self.saveKeyHeight[string] = size.height + 15
        return size.height + 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogContentCell
        let string = self.m_dataArray[indexPath.section][indexPath.row]
        tableviewCell.setCellContent(content: string, width: self.width - 20, keyDic: self.keyDic)
        tableviewCell.backgroundColor = self.saveMainBgDic[self.m_dataArray[indexPath.section][indexPath.row]]
        var isHidden = true
        if self.m_startDate1.count > 0 && string.count >= self.m_startDate1.count {
            let key11 = (string as NSString).substring(to: self.m_startDate1.count) as! String
            if key11 >= self.m_startDate1 {
                isHidden = false
            }
        }
        if self.m_endDate1.count > 0 && string.count >= self.m_endDate1.count {
            let key11 = (string as NSString).substring(to: self.m_endDate1.count) as! String
            if key11 > self.m_endDate1 {
                isHidden = true
            }
        }
        tableviewCell.topImageView?.isHidden = isHidden
        return tableviewCell
    }
}

