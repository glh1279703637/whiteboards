//
//  JLogDefaultConfig.swift
//  Logminer
//
//  Created by Jeffrey on 2022/12/16.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

typealias klogDefaultCallback = ((_ key : String, _ add : Bool) -> ())

class JLogDefaultConfigCell : JBaseTableViewCell {
    var contentLabel : UILabel?
    var selectButton : UIButton?
    override func funj_addBaseTableSubView() {
        contentLabel = UILabel(i: CGRect(x: 10, y: 0, width: 380, height: 30), title: nil, textFC: JTextFC(f: kFont_Size14, c: kColor_Text_Black))
        self.contentView.addSubview(contentLabel!)
        selectButton = UIButton(i: CGRect(x: 370, y: 0, width: 30, height: 30), title: "", textFC: JTextFC(f: kFont_Size13, c: kColor_Orange))
            .funj_add(bgImageOrColor: ["studying_rb_n", "studying_rb_s"], isImage: true)
        selectButton?.isUserInteractionEnabled = false
        self.contentView.addSubview(selectButton!)
    }
}

class JLogDefaultConfigView : JBaseTableViewVC {
    internal var m_clickCallback : klogDefaultCallback?
    var m_saveSelectItem : [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.isHidden = true
        self.view.funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Orange))
        self.m_tableView.register(JLogDefaultConfigCell.self, forCellReuseIdentifier: kCellIndentifier)
        self.m_tableView.separatorStyle = .singleLine
        
        let path2 = NSHomeDirectory() + "/Documents/logminer/logDefaultFile";
        if FileManager.default.fileExists(atPath: path2) == false {
            let url = URL(fileURLWithPath: path2)
            try? "".write(to: url, atomically: true, encoding: .utf8)
        }

        self.funj_reloadDatas()
    }
    func funj_reloadDatas() {
        let path1 = NSHomeDirectory() + "/Documents/logminer/logkeyfile";
        let url1 = URL(fileURLWithPath: path1)
        if let data = try? String(contentsOf: url1, encoding: .utf8) {
            let dataArr = data.components(separatedBy: "\n")
            self.m_saveSelectItem.removeAll()
            for str in dataArr {
                self.m_saveSelectItem.append(str.lowercased())
            }
        }
        
        let path2 = NSHomeDirectory() + "/Documents/logminer/logDefaultFile";
        let url2 = URL(fileURLWithPath: path2)
        if let data = try? String(contentsOf: url2, encoding: .utf8) {
            let dataArr = data.components(separatedBy: "\n")
            self.m_dataArr.removeAll()
            self.m_dataArr += dataArr
            super.funj_reloadData()
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.funj_reloadTableView(CGRectZero, table:CGRect(x: 0, y: 0, width: 400, height: self.view.height))
        self.m_tableView.reloadData()
    }
}
extension JLogDefaultConfigView {
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableviewCell = tableView.dequeueReusableCell(withIdentifier: kCellIndentifier) as! JLogDefaultConfigCell
        let key = self.m_dataArr[indexPath.row] as! String;
        tableviewCell.contentLabel?.text = key
        let isHead = (key.hasPrefix("##") || key.count == 0)
        tableviewCell.selectButton?.isSelected = self.m_saveSelectItem.contains(key.lowercased())
        tableviewCell.selectButton?.isHidden = isHead
        tableviewCell.contentLabel?.left = isHead ? 0 : 10
        tableviewCell.contentLabel?.textColor = isHead ? kColor_Text_GRAY : kColor_Text_Black
        tableviewCell.selectButton?.tag = indexPath.row
        return tableviewCell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let string = self.m_dataArr[indexPath.row] as! String;
        let isHead = (string.hasPrefix("##") || string.count == 0)
        if isHead { return }

        let cell = self.m_tableView.cellForRow(at: indexPath) as! JLogDefaultConfigCell
        if !self.m_saveSelectItem.contains(string.lowercased()) {
            self.m_saveSelectItem.append(string.lowercased())
            cell.selectButton?.isSelected = true
        } else {
            cell.selectButton?.isSelected = false
            self.m_saveSelectItem.removeAll { str in
                str == string.lowercased()
            }
        }
        self.m_clickCallback?(string, cell.selectButton!.isSelected)
    }
}
