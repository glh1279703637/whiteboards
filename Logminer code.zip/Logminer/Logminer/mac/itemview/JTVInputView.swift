//
//  JTVInputView.swift
//  Logminer
//
//  Created by Jeffrey on 2022/12/16.
//  Copyright © 2022 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JTVInputView : UIView, UITextViewDelegate {
    var m_contentView : UITextView?
    var m_pathKey : String = ""
    var m_saveDate : String = ""
    var m_isConclusionView  = false
    internal var m_clickCallback : kcompleteCallback?
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    init(_ title : String, path : String) {
        super.init(frame: CGRectZero)
        self.backgroundColor = kColor_White
        self.funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Red))
        self.isHidden = true
        self.m_pathKey = path
        let keyContentView = UITextView(i: CGRectZero, textFC: JTextFC(f: kFont_Size14, c: kColor_Blue)).funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Red))
        self.addSubview(keyContentView)
        keyContentView.layer.masksToBounds = false
        keyContentView.backgroundColor = kColor_White
        keyContentView.delegate = self
        keyContentView.autocorrectionType = .no
        m_contentView = keyContentView
        
        let label = UILabel(i: CGRect(x: 0, y: 0, width: 500, height: 20), title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_Text_GRAY, a: .left))
        self.addSubview(label)
        
        let button = UIButton(i: CGRect(x: 0, y: 0, width: 50, height: 20), title: "确定", textFC: JTextFC(f: kFont_Size15, c: kColor_Orange)).funj_saveBgColor([kColor_Orange]).funj_addblock { [weak self] button in
            if self!.m_isConclusionView && self!.m_saveDate.count > 0 {
                self?.funj_saveConfigFileToTarget(false)
                let height = self?.m_contentView?.height
                var height2 = JAppUtility.funj_getTextW_Height(self?.m_contentView?.text, textFont: kFont_Size14, layoutwidth: self!.m_contentView!.width, layoutheight: height!).height + 10 + 20
                self?.height = height2
                self?.funj_startShareScreenCapt()
                self?.height = height!
            }

            self?.isHidden = true
            self?.textViewShouldEndEditing(self!.m_contentView!)
            self?.m_clickCallback?()
            
        }
        button.tag = 304;
        self.addSubview(button)
        
        self.funj_reloadDataConfig()
    }
    func funj_getContentPath() -> String{
        var path2 = NSHomeDirectory() + "/Documents/logminer/\(self.m_pathKey)";
        if self.m_isConclusionView {
            path2 = NSHomeDirectory() + "/Documents/logminer/history/\(self.m_saveDate)/\(self.m_pathKey)";
        }
        return path2
    }
    func funj_reloadDataConfig() {
        let path2 = self.funj_getContentPath()
        let url2 = URL(fileURLWithPath: path2)
        if let texts = try? String(contentsOf: url2, encoding: .utf8)  {
            m_contentView!.text = texts
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.m_contentView?.frame = CGRect(x: 0, y: 20, width: self.width, height: self.height - 20)
        let button = self.viewWithTag(304)
        button?.left = self.width - 50
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        var string = textView.text
        if !self.m_isConclusionView {
            let array = string!.components(separatedBy: "\n")
            var keyDic:[String : String] = [:]
            var newArray : [String] = []
            for key in array {
                if key.count > 0 {
                    if keyDic[key] == nil {
                        newArray.append(key)
                    }
                    keyDic[key] = ""
                }
            }
            string = newArray.joined(separator: "\n")
        }
        if self.m_isConclusionView && self.m_saveDate.count <= 0 {
            return true
        }
        
        let url = URL(fileURLWithPath: self.funj_getContentPath())
        try? string?.write(to: url, atomically: true, encoding: .utf8)
        return true
    }
    func funj_saveConfigFileToTarget(_ copy : Bool) {
        // false 复制到保存， true 反向还原
        var root = NSHomeDirectory() + "/Documents/logminer/";
        let path2 = self.funj_getContentPath()
        var path3 = URL(fileURLWithPath: path2).deletingLastPathComponent().path
        
        if copy {
            let root2 = root.substring(to: root.index(root.startIndex, offsetBy: root.count - 1))
            root = path3 + "/"
            path3 = root2
        }
        
        if let fileList = try? FileManager.default.contentsOfDirectory(atPath: root) {
            for title in fileList {
                if title.hasPrefix("log") {
                    let path4 = path3 + "/" + title
                    if FileManager.default.fileExists(atPath: path4) {
                        try? FileManager.default.removeItem(atPath: path4)
                    }
                    let path5 = root + title
                    try? FileManager.default.copyItem(atPath: path5, toPath: path4)
                }
            }
        }
    }
    func funj_startShareScreenCapt() {
        let path2 = self.funj_getContentPath()
        let url2 = URL(fileURLWithPath: path2)
        if let view = self.superview {
            UIGraphicsBeginImageContext(view.frame.size)
            let ctx : CGContext = UIGraphicsGetCurrentContext()!
            view.layer.render(in: ctx)
            if let image = UIGraphicsGetImageFromCurrentImageContext()  {
                let dataimag = UIImage.pngData(image)
                let path3 = url2.deletingLastPathComponent().path + "/result.png"
                if FileManager.default.fileExists(atPath: path3) {
                    let path4 = path3.replacingOccurrences(of: "result.png", with: "result-\(JAppUtility.funj_getDateTime("HHmmss")).png")
                    try? FileManager.default.copyItem(atPath: path3, toPath: path4)
                    try? FileManager.default.removeItem(atPath: path3)
                }
                FileManager.default.createFile(atPath: path3, contents: dataimag()!, attributes: nil)
            }
            UIGraphicsEndImageContext()
        }
    }
}
