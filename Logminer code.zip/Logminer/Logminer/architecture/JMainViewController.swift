//
//  JMainViewController.swift
//  Logminer
//
//  Created by Jeffrey on 2020/9/25.
//

import UIKit
import Foundation
import AppKit
import CoreMedia

@objcMembers
class JMainViewController: JBaseCollectionVC, UITextFieldDelegate, UITextViewDelegate {
    var saveDataArr : [JLogContentTableView] = []
    var saveDataDic : NSMutableDictionary = [:]
    var logFileItemView : JLogFileItemView?
    var m_textField : UITextField?
    var m_sceneBt : UIButton?
    var m_isOnlyShowInfo = false
    var m_keyContentView : JTVInputView?
    var m_keyDeleteContentView : JTVInputView?
    var m_matchContentView : JTVInputView?
    var m_conclusionContentView : JTVInputView?
    var logMainContentView : JLogContentTableView?
    var logDefaultConfigView : JLogDefaultConfigView?
    var logDefaultConfigView1 : JLogDefaultConfigView?
    var logDefaultConfigView2 : JLogDefaultConfigView?
    var logHistoryView : JLogHistoryView?
    
    var m_saveKeyColorDic : [String : UIColor] = [ : ]
    var m_saveMatchColorDic : [String : UIColor] = [ : ]

    var m_prefixTF22 : UITextField?
    var m_prefixTF23 : UITextField?
    
    var m_solverDateKey = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        funj_addBaseConfig()
        let flowlayout = self.m_collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flowlayout.scrollDirection = .horizontal
        self.m_collectionView.isScrollEnabled = false
        
        logMainContentView = JLogContentTableView()
        self.view.addSubview(logMainContentView!)
        logMainContentView!.titleLabel?.text = "Main";
        let path = NSHomeDirectory() + "/Documents/logminer/mainContent.txt"
        logMainContentView?.m_savePath = path
        logMainContentView!.m_isOnlyShowInfo = true;
        logMainContentView?.backgroundColor = kColor_White
        logMainContentView?.isHidden = true
        logMainContentView?.funj_reloadMainContentView()
        
        funj_addLogFileItemView()
        funj_addSubBtContentView()
        funj_getDefaultConfigView()
        funj_getLogHistoryView()
    }
    func funj_addBaseConfig() {
        let path = NSHomeDirectory() + "/Documents/logminer/"
        if !FileManager.default.fileExists(atPath: path) {
            try? FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
            let path = NSHomeDirectory() + "/Documents/logminer/history/"
            try? FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
        }
        let date1 = UserDefaults.standard.string(forKey: "startTimeDefault") ?? ""
        let date2 = UserDefaults.standard.string(forKey: "endTimeDefault") ?? ""
        m_prefixTF22 = JLogContentTableView.funj_getTextField(date1, "2022-11-11 10:22:20")
        m_prefixTF23 = JLogContentTableView.funj_getTextField(date2, "2022-11-11 10:22:24")
        m_prefixTF22?.delegate = self
        m_prefixTF23?.delegate = self;
        self.view.addSubview(m_prefixTF22!)
        self.view.addSubview(m_prefixTF23!)
        
        NotificationCenter.default.addObserver(forName: Notification.Name(rawValue: "postFileToResetViewNotifaction"), object: nil, queue: OperationQueue.main) { notification in
            self.funj_resetAllViewInfo(true)
            self.m_solverDateKey = notification.object as! String
            self.m_conclusionContentView?.m_saveDate = self.m_solverDateKey
            self.m_conclusionContentView?.funj_saveConfigFileToTarget(true)
        }
    }
    func funj_addSubBtContentView() {
        let bgView = UIView(i: CGRect(x: 0, y: kStatusBarHeight, width: 500, height: 30), bg: kColor_Bg_Lightgray)
        bgView.tag = 5000;
        self.view.addSubview(bgView)
        
        let titleArr = ["导入", "重置", "仅显示", "主界面", "排除", "关键字", "流程", "写结论", "历史"]
        var index = 0;
        for title in titleArr {
            let button = UIButton(i: CGRect(x: 20 + 60 * index , y: 0, width: 50, height: Int(bgView.height)), title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_Red))
                .funj_add(targe: self, action: "funj_selectActionTo:", tag: index + 1001)
            bgView.addSubview(button)
            index += 1
        }
        m_textField = UITextField(i: CGRect(x: 0, y: 10, width: 40, height: 20), placeholder: "分栏", textFC: JTextFC(f: kFont_Size12, c: kColor_White, a:.center))
        m_textField?.backgroundColor = kColor_Orange
        m_textField?.text = "1"
        m_textField?.delegate = self;
        bgView.addSubview(m_textField!)
        m_sceneBt = UIButton(i: CGRect(x: 0, y: 0, width: 30, height: 30), title: nil, textFC: JTextFC(f: kFont_Size12, c: kColor_White))
            .funj_add(bgImageOrColor: ["whiteboard_vote_vote_add"], isImage: true)
            .funj_addblock(block: { button in
                let activity = NSUserActivity(activityType: "scence\(arc4random())")
                UIApplication.shared.requestSceneSessionActivation(nil, userActivity: activity, options: nil, errorHandler: nil)
            })
        bgView.addSubview(m_sceneBt!)
                
        m_keyContentView = JTVInputView("关键字 如：key1", path : "logkeyfile")
        self.view.addSubview(m_keyContentView!)
        m_keyContentView?.m_clickCallback = { [ self] in
            self.logDefaultConfigView?.view.isHidden = true
            self.funj_getKeyContentItem()
            self.logMainContentView?.funj_reloadData()
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_reloadData()
            }
        }
        
        m_keyDeleteContentView = JTVInputView("排除 如：key1", path : "logDelkeyfile")
        self.view.addSubview(m_keyDeleteContentView!)
        m_keyDeleteContentView?.m_clickCallback = { [self] in
            self.logDefaultConfigView1?.view.isHidden = true
            self.funj_solverDataArray(logMainContentView!)
            for logView in self.saveDataArr {
                self.funj_solverDataArray(logView)
            }
        }

        m_matchContentView = JTVInputView("流程 如：firstkey<>secordkey<>lastkey", path : "logMatchkeyfile")
        self.view.addSubview(m_matchContentView!)
        m_matchContentView?.m_clickCallback = { [self] in
            self.logDefaultConfigView2?.view.isHidden = true
            self.funj_getMatchContentItem()
            self.logMainContentView?.funj_reloadToMatchValue()
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_reloadToMatchValue()
            }
        }
        m_conclusionContentView = JTVInputView("分析结果", path : "readme.txt")
        m_conclusionContentView?.m_isConclusionView = true
        m_conclusionContentView?.height = 500
        self.view.addSubview(m_conclusionContentView!)
    }

    func funj_getKeyContentItem() {
        let string = m_keyContentView!.m_contentView!.text
        let array = string!.components(separatedBy: "\n")
        var saveKeyColorDic : [String : UIColor] = [:]
        for (key, value) in self.m_saveKeyColorDic {
            saveKeyColorDic[key] = value
        }
        self.m_saveKeyColorDic.removeAll()
        for key in array {
            if key.count > 0 {
                if saveKeyColorDic[key] == nil {
                    m_saveKeyColorDic[key] = krandomColors(alpha: 0.5)
                } else {
                    m_saveKeyColorDic[key] = saveKeyColorDic[key]
                }
            }
        }
        logMainContentView?.keyDic = self.m_saveKeyColorDic
        for logContentView in self.saveDataArr {
            logContentView.keyDic = self.m_saveKeyColorDic
        }
    }
    func funj_getMatchContentItem() {
        let string = m_matchContentView!.m_contentView!.text
        let array = string!.components(separatedBy: "\n")
        
        var saveKeyColorDic : [String : UIColor] = [:]
        for (key, value) in self.m_saveMatchColorDic {
            saveKeyColorDic[key] = value
        }
        self.m_saveMatchColorDic.removeAll()
        for key in array {
            if key.count > 0 {
                if saveKeyColorDic[key] == nil {
                    m_saveMatchColorDic[key] = krandomColors(alpha: 0.8)
                } else {
                    m_saveMatchColorDic[key] = saveKeyColorDic[key]
                }
            }
        }
        logMainContentView?.m_saveMatchColorDic = self.m_saveMatchColorDic
        for logContentView in self.saveDataArr {
            logContentView.m_saveMatchColorDic = self.m_saveMatchColorDic
        }
    }
    func funj_getDefaultConfigView() {
        logDefaultConfigView = JLogDefaultConfigView()
        logDefaultConfigView?.m_fileKey = "keyContentList"
        self.view.addSubview(logDefaultConfigView!.view)
        logDefaultConfigView?.m_clickCallback = { [weak self] (title, isAdd) in
            let string = self?.m_keyContentView!.m_contentView!.text
            var array = string!.components(separatedBy: "\n")
            if isAdd {
                array.append(title)
            } else {
                array.removeAll { str in
                    str.lowercased() == title.lowercased()
                }
            }
            self?.m_keyContentView?.m_contentView?.text = array.joined(separator: "\n")
            self?.m_keyContentView?.textViewShouldEndEditing(self!.m_keyContentView!.m_contentView!)
        }
        logDefaultConfigView1 = JLogDefaultConfigView()
        logDefaultConfigView1?.m_fileKey = "deleteContentList"
        self.view.addSubview(logDefaultConfigView1!.view)
        logDefaultConfigView1?.m_clickCallback = { [weak self] (title, isAdd) in
            let string = self?.m_keyDeleteContentView!.m_contentView!.text
            var array = string!.components(separatedBy: "\n")
            if isAdd {
                array.append(title)
            } else {
                array.removeAll { str in
                    str.lowercased() == title.lowercased()
                }
            }
            self?.m_keyDeleteContentView?.m_contentView?.text = array.joined(separator: "\n")
            self?.m_keyDeleteContentView?.textViewShouldEndEditing(self!.m_keyDeleteContentView!.m_contentView!)
        }
        logDefaultConfigView2 = JLogDefaultConfigView()
        logDefaultConfigView2?.m_fileKey = "matchContentList"
        self.view.addSubview(logDefaultConfigView2!.view)
        logDefaultConfigView2?.m_clickCallback = { [weak self] (title, isAdd) in
            let string = self?.m_matchContentView!.m_contentView!.text
            var array = string!.components(separatedBy: "\n")
            if isAdd {
                array.append(title)
            } else {
                array.removeAll { str in
                    str.lowercased() == title.lowercased()
                }
            }
            self?.m_matchContentView?.m_contentView?.text = array.joined(separator: "\n")
            self?.m_matchContentView?.textViewShouldEndEditing(self!.m_matchContentView!.m_contentView!)
        }
    }
    func funj_getLogHistoryView() {
        logHistoryView = JLogHistoryView()
        self.view.addSubview(logHistoryView!.view)
    }
    func funj_addLogFileItemView() {
        logFileItemView = JLogFileItemView();
        self.view.addSubview(logFileItemView!.view)
        logFileItemView?.view.layer.borderWidth = 2;
        logFileItemView?.view.layer.borderColor = kColor_Red.cgColor
        logFileItemView?.view?.isHidden = true
        
        logFileItemView?.m_logFileCallback = { [weak self] (path, title, dataArr) in
            if ((self?.saveDataDic[title]) != nil) {
                return
            }
            self?.funj_resetAllViewInfo(false)
            
            let path2 = NSHomeDirectory() + "/Documents/logminer/history/" + self!.m_solverDateKey + "/openFile.txt"
            let url2 = URL(fileURLWithPath: path2)
            var content = try? String(contentsOf: url2, encoding: .utf8)
            if content == nil { content = "" }
            if !content!.contains(path) {
                content! += "\n\(path)"
                try? content!.write(toFile: path2, atomically: true, encoding: .utf8)
            }
            
            self?.saveDataDic[title] = ""
            let logMainContentView = JLogContentTableView()
            logMainContentView.titleLabel?.text = title;
            logMainContentView.m_savePath = path
            logMainContentView.backgroundColor = krandomColors(alpha: 0.05)
            logMainContentView.m_dataArray.removeAll()
            logMainContentView.m_dataArray += dataArr
            logMainContentView.keyDic = self!.m_saveKeyColorDic
            logMainContentView.m_startDate1 = self?.m_prefixTF22?.text ?? ""
            logMainContentView.m_endDate1 = self?.m_prefixTF23?.text ?? ""
            logMainContentView.funj_reloadButton()
            logMainContentView.funj_reloadData()
            logMainContentView.m_selectRowCallback = { [weak self, logMainContentView] (title) in
                if logMainContentView != self?.logMainContentView {
                    self?.logMainContentView?.funj_updateToScrollCell(title)
                }
                for logContentView in self!.saveDataArr {
                    if logContentView != logMainContentView {
                        logContentView.funj_updateToScrollCell(title)
                    }
                }
            }
            self?.saveDataArr.append(logMainContentView)
            self?.logMainContentView!.isHidden = true
            self?.view.setNeedsLayout()
            let index  = CGFloat(self?.saveDataArr.count ?? 0) - 1
            self?.m_collectionView.reloadData()
            var count : CGFloat = CGFloat((self?.m_textField!.text as NSString? ?? "1").floatValue)
            count = max(count, 1)
            let index2 = Int(index / count)
            self?.m_collectionView.setContentOffset(CGPoint(x: CGFloat(index2) * (self?.m_collectionView.width ?? 0), y: 0), animated: true)
            
            let button = UIButton(i: CGRect(x: (self?.view.width ?? 30) - 30, y: CGFloat(25 * (self?.saveDataArr.count ?? 0)) + kStatusBarHeight + 50, width: 30, height: 20), title: title, textFC: JTextFC(f: kFont_Size11, c: kColor_White))
                .funj_add(targe: self, action: "selectPageTo:", tag: 100300 + (self?.saveDataArr.count ?? 0))
            button.funj_updateContentImage(layout: .kLEFT_CONTENTIMAGE, a: JAlignValue(h: 4, s: 0, f: 0))
            button.backgroundColor = kColor_Orange
            button.width = JAppUtility.funj_getTextWidthWithView(button) + 10 + 20
            self?.view.insertSubview(button, belowSubview: (self?.logHistoryView?.view)!)
            let button1 = UIButton(i: CGRect(x: button.width - 20, y:0, width: 20, height: 20), title: "切", textFC: JTextFC(f: kFont_Size11, c: kColor_White))
                    .funj_add(targe: self, action: "selectChangePageTo:", tag: 10300 + (self?.saveDataArr.count ?? 0))
                button1.backgroundColor = kColor_Text_GRAY
                button.addSubview(button1)
            
        }
    }
    func funj_resetAllViewInfo(_ isMust : Bool) {
        if !isMust {
            if self.m_solverDateKey.count > 0 { return }
            self.m_solverDateKey = JAppUtility.funj_getDateTime("yyyyMMddHHmmss")
            self.m_conclusionContentView?.m_saveDate = self.m_solverDateKey
            let path = NSHomeDirectory() + "/Documents/logminer/history/" + self.m_solverDateKey + "/"
            try? FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
        } else {
            self.m_solverDateKey = ""
            self.view.setNeedsLayout()
            self.saveDataDic.removeAllObjects()
            self.logMainContentView?.m_dataArray.removeAll()
            self.logMainContentView?.funj_reloadData()
            self.saveDataArr.removeAll()
            for view in self.view.subviews {
                if view.tag >= 100300 {
                    view.removeFromSuperview()
                }
            }
            self.m_collectionView.reloadData()
        }
        
    }
    @objc func funj_selectActionTo(_ sender : UIButton? = nil ) {
        let selectViewArr : [[UIView]] = [[self.logFileItemView!.view], [], [], [], [m_keyDeleteContentView!,logDefaultConfigView1!.view], [m_keyContentView!, logDefaultConfigView!.view], [m_matchContentView!,logDefaultConfigView2!.view], [m_conclusionContentView!], [logHistoryView!.view]]
        
        let viewArr : [UIView] = [self.logFileItemView!.view, m_keyDeleteContentView!, m_keyContentView!, logDefaultConfigView!.view,logDefaultConfigView1!.view,logDefaultConfigView2!.view, m_matchContentView!, m_conclusionContentView!, logHistoryView!.view]
        let selectArr = selectViewArr[sender!.tag - 1001]
        for view in viewArr {
            if selectArr.contains(view) {
                view.isHidden = !view.isHidden
            } else {
                view.isHidden = true
            }
        }
        
        if(sender!.tag == 1001) { // "导入"
            self.logFileItemView?.funj_reloadDatas()
        } else if(sender!.tag == 1002) { // 重置
            self.funj_resetAllViewInfo(true)
        } else if(sender!.tag == 1003) { // 仅显示
            self.m_isOnlyShowInfo = !self.m_isOnlyShowInfo
            for logMainContentView in self.saveDataArr {
                logMainContentView.m_isOnlyShowInfo = self.m_isOnlyShowInfo
                logMainContentView.funj_reloadData()
            }
        } else if(sender!.tag == 1004) { // 主界面
            self.logMainContentView!.isHidden = !self.logMainContentView!.isHidden;
            if self.logMainContentView!.isHidden == false {
                self.funj_reloadAllToMain()
            }
        } else if(sender!.tag == 1005) { // 排除
            if m_keyDeleteContentView!.isHidden == false  {
                m_keyDeleteContentView?.funj_reloadDataConfig()
                self.logDefaultConfigView1!.funj_reloadDatas()
            }
        } else if(sender!.tag == 1006) {// 关键字
            if m_keyContentView!.isHidden == false  {
                m_keyContentView?.funj_reloadDataConfig()
                self.logDefaultConfigView!.funj_reloadDatas()
            }
        } else if(sender!.tag == 1007) { // 流程
            if m_matchContentView!.isHidden == false  {
                m_matchContentView?.funj_reloadDataConfig()
                self.logDefaultConfigView2!.funj_reloadDatas()
            }
        } else if(sender!.tag == 1008) { // 写结论
            if m_conclusionContentView!.isHidden == false  {
                m_conclusionContentView?.funj_reloadDataConfig()
            }
        } else if(sender!.tag == 1009) { // 历史
            if logHistoryView!.view!.isHidden == false  {
                logHistoryView?.funj_reloadDatas()
            }
        }
    }
    @objc func selectPageTo(_ sender : UIButton? = nil ) {
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        let index = Int((sender!.tag - 100301) / count)
        self.m_collectionView.setContentOffset(CGPoint(x: CGFloat(index) * self.m_collectionView.width , y: 0), animated: true)
    }
    @objc func selectChangePageTo(_ sender : UIButton? = nil ) {
        let index = (sender!.tag - 10301)
        let index2 = index + 100301 - 1
        let index3 = index + 100301
        if index >= 1 {
            let button1 = self.view.viewWithTag(index2) as? UIButton
            let button2 = self.view.viewWithTag(index3) as? UIButton
            let title = button2?.titleLabel?.text
            button2?.setTitle(button1?.titleLabel?.text, for: .normal)
            button1?.setTitle(title, for: .normal)
            let logMainContentView = self.saveDataArr[index];
            self.saveDataArr.remove(at: index)
            self.saveDataArr.insert(logMainContentView, at: index - 1)
            
            for button in self.view.subviews {
                if button.tag >= 100300 {
                    button.width = JAppUtility.funj_getTextWidthWithView(button) + 10 + 20
                    button.left = self.view.width - button.width - 10
                    let button2 = button.subviews.last
                    button2?.left = button.width - 20
                }
            }
            self.m_collectionView.reloadData()

        }

    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.isEqual(to: m_prefixTF22) || textField.isEqual(to: m_prefixTF23) {
            var startkey = "startTimeDefault"
            if textField.isEqual(to: m_prefixTF23) {
                startkey = "endTimeDefault"
            }
            UserDefaults.standard.set(textField.text, forKey: startkey)
            self.funj_reloadAllToMain()
            self.logMainContentView?.funj_updateToScrollCell(textField.text!)
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_updateToScrollCell(textField.text!)
            }
        }
        self.view.setNeedsLayout()
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        m_collectionView.frame = CGRect(x: 0, y: kStatusBarHeight + 30, width: self.view.width, height: self.view.height - kStatusBarHeight - 30)
        logMainContentView?.frame = CGRect(x: 0, y: self.logMainContentView!.m_splitTopPoint, width: self.view.width, height: self.view.height - self.logMainContentView!.m_splitTopPoint)
        let bgView = self.view.viewWithTag(5000)
        bgView?.width = self.view.width
        
        logFileItemView?.view.frame = CGRect(x: (self.view.width - 400)/2, y: kStatusBarHeight + 40, width: 400, height: 500);

        
        m_keyContentView?.frame = logFileItemView!.view.frame
        m_keyContentView?.left -= logFileItemView!.view.width / 2
        m_keyDeleteContentView?.frame = m_keyContentView!.frame
        m_matchContentView?.frame = m_keyContentView!.frame
        
        logDefaultConfigView?.view.frame = logFileItemView!.view.frame
        logDefaultConfigView?.view.left = m_keyContentView!.right
        logDefaultConfigView1?.view.frame = logDefaultConfigView!.view.frame
        logDefaultConfigView2?.view.frame = logDefaultConfigView!.view.frame
        
        m_conclusionContentView?.frame = CGRect(x: self.view.width - m_conclusionContentView!.width - 10, y: kStatusBarHeight + 40, width: logFileItemView!.view.width, height: m_conclusionContentView!.height)
        logHistoryView?.view.frame = CGRect(x: self.view.width - 500, y: kStatusBarHeight + 30, width: 500, height: self.view.height - (kStatusBarHeight + 30))


        m_textField?.left = self.view.width - 70;
        m_sceneBt?.left = self.view.width - 30;
        
        m_prefixTF22?.left = self.view.width - 360; m_prefixTF22?.width = 180
        m_prefixTF22?.top = self.view.height - 20;
        m_prefixTF23?.left = self.view.width - 180;m_prefixTF23?.width = 180;
        m_prefixTF23?.top = self.view.height - 20;

        for button in self.view.subviews {
            if button.tag >= 100300 {
                button.left = self.view.width - button.width - 10
            }
        }
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        for logContentView in self.saveDataArr {
            logContentView.width = self.m_collectionView.width / CGFloat(count)
            logContentView.height = self.m_collectionView.height
        }
        self.m_collectionView.reloadData()
    }
}

extension JMainViewController {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.saveDataArr.count
    }
    override func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        return CGSize(width: self.view.width / CGFloat(count), height: collectionView.height)
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: kCellIndentifier, for: indexPath)
        let index : Int = Int(self.m_textField!.text ?? "1") ?? 1
        let logContentView = self.saveDataArr[indexPath.row]
        for view in cell.contentView.subviews {
            view.removeFromSuperview()
        }
        logContentView.width = collectionView.width / CGFloat(index)
        logContentView.height = collectionView.height
        cell.contentView.addSubview(logContentView)
        return cell
    }
}

extension JMainViewController {
    func funj_reloadAllToMain() {
        let first1 = self.m_prefixTF22!.text
        let last1 = self.m_prefixTF23!.text
        
        logMainContentView!.m_startDate1 = self.m_prefixTF22?.text ?? ""
        logMainContentView!.m_endDate1 = self.m_prefixTF23?.text ?? ""
        let index = Int(logMainContentView?.m_prefixTF?.text ?? "36")!

        var saveAllArr : [String] = []
        for logContentView in self.saveDataArr  {
            logContentView.m_startDate1 = self.m_prefixTF22?.text ?? ""
            logContentView.m_endDate1 = self.m_prefixTF23?.text ?? ""
            logContentView.funj_reloadData()
            if logMainContentView!.isHidden { continue }
            
            let color = krandomColors(alpha: 0.2)
            for array in logContentView.m_dataArray {
                for str in array {
                    let key11 = (str as NSString).substring(to: min(index, str.count)) as! String
                    if key11 < first1! || key11 > last1! {
                        continue
                    }

                    for (key,_) in self.m_saveKeyColorDic {
                        if str.lowercased().contains(key.lowercased()) {
                            saveAllArr.append(str)
                            logMainContentView?.saveMainBgDic[str] = color;
                            break
                        }
                    }
                }
            }
        }
        if logMainContentView!.isHidden { return }

        let first = logMainContentView?.m_prefixTF1?.text
        let last = logMainContentView?.m_prefixTF2?.text
        
        saveAllArr = saveAllArr.sorted { key1, key2 in
            var key11 = (key1 as NSString).substring(to: min(key1.count, index))
            var key22 = (key2 as NSString).substring(to: min(key2.count, index))
            if first != nil && last != nil {
                key11 = key11.replacingOccurrences(of: first!, with: last!)
                key22 = key22.replacingOccurrences(of: first!, with: last!)
            }
            return key11 < key22
        }

        logMainContentView?.m_dataArray = [saveAllArr]
        logMainContentView?.funj_reloadData()
        logMainContentView?.funj_reloadButton()
    }
    func funj_solverDataArray(_ logView : JLogContentTableView) {
        let string = self.m_keyDeleteContentView!.m_contentView!.text
        let array = string!.components(separatedBy: "\n")
        for key in array {
            var dataArray : [[String]] = []
            for var array2 in logView.m_dataArray {
                array2.removeAll { key1 in
                    return key1.lowercased().contains(key.lowercased())
                }
                dataArray.append(array2)
            }
            logView.m_dataArray.removeAll()
            logView.m_dataArray += dataArray
        }
        logView.funj_reloadData()
        logView.funj_reloadButton()
    }
}
