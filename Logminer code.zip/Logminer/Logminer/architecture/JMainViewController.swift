//
//  JMainViewController.swift
//  Logminer
//
//  Created by Jeffrey on 2020/9/25.
//

import UIKit
import Foundation
import AppKit
import CoreMedia

@objcMembers
class JMainViewController: JBaseCollectionVC, UITextFieldDelegate, UITextViewDelegate {
    var saveDataArr : [JLogContentTableView] = []
    var saveDataDic : NSMutableDictionary = [:]
    var logFileItemView : JLogFileItemView?
    var m_textField : UITextField?
    var m_isOnlyShowInfo = false
    var m_keyContentView : UITextView?
    var m_keyDeleteContentView : UITextView?
    var m_matchContentView : UITextView?
    var logMainContentView : JLogContentTableView?
    var m_saveKeyColorDic : [String : UIColor] = [ : ]
    var m_saveMatchColorDic : [String : UIColor] = [ : ]

    var m_prefixTF22 : UITextField?
    var m_prefixTF23 : UITextField?

    override func viewDidLoad() {
        super.viewDidLoad()
        let flowlayout = self.m_collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flowlayout.scrollDirection = .horizontal
        self.m_collectionView.isScrollEnabled = false
        
        funj_addLogFileItemView()
        funj_addBaseConfig()
        
        logMainContentView = JLogContentTableView()
        self.view.addSubview(logMainContentView!)
        logMainContentView!.titleLabel?.text = "Main";
        let path = NSHomeDirectory() + "/Documents/logminer/mainContent.txt"
        logMainContentView?.m_savePath = path
        logMainContentView!.m_isOnlyShowInfo = true;
        logMainContentView?.backgroundColor = kColor_White
        logMainContentView?.isHidden = true
        logMainContentView?.funj_reloadMainContentView()
        
        funj_addSubBtContentView()
    }
    func funj_addBaseConfig() {
        let path = NSHomeDirectory() + "/Documents/logminer/"
        if !FileManager.default.fileExists(atPath: path) {
            try? FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
        }
        let date1 = UserDefaults.standard.string(forKey: "startTimeDefault") ?? ""
        let date2 = UserDefaults.standard.string(forKey: "endTimeDefault") ?? ""
        m_prefixTF22 = JLogContentTableView.funj_getTextField(date1, "2022-11-11 10:22:20")
        m_prefixTF23 = JLogContentTableView.funj_getTextField(date2, "2022-11-11 10:22:24")
        m_prefixTF22?.delegate = self
        m_prefixTF23?.delegate = self;
        self.view.addSubview(m_prefixTF22!)
        self.view.addSubview(m_prefixTF23!)
        
    }
    func funj_addSubBtContentView() {
        let bgView = UIView(i: CGRect(x: 0, y: kStatusBarHeight, width: 500, height: 30), bg: kColor_Bg_Lightgray)
        bgView.tag = 5000;
        self.view.addSubview(bgView)
        
        let titleArr = ["导入", "刷新", "仅显示", "排除", "主界面", "关键字", "配对"]
        var index = 0;
        for title in titleArr {
            let button = UIButton(i: CGRect(x: 20 + 60 * index , y: 0, width: 50, height: Int(bgView.height)), title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_Red))
                .funj_add(targe: self, action: "funj_selectActionTo:", tag: index + 1001)
            bgView.addSubview(button)
            index += 1
        }
        m_textField = UITextField(i: CGRect(x: 0, y: -20, width: 30, height: 20), placeholder: "分页", textFC: JTextFC(f: kFont_Size12, c: kColor_White))
        m_textField?.backgroundColor = kColor_Orange
        m_textField?.text = "1"
        m_textField?.delegate = self;
        bgView.addSubview(m_textField!)
                
        m_keyContentView = self.funj_getContentView("关键字 如：key1", path : "logkeyfile")
        m_keyDeleteContentView = self.funj_getContentView("排除 如：key1", path : "logDelkeyfile")
        m_matchContentView = self.funj_getContentView("配对 如：firstkey<>lastkey", path : "logMatchkeyfile")
        
        self.funj_getKeyContentItem()
        self.funj_getMatchContentItem()
    }
    func funj_getContentView(_ title : String, path : String) -> UITextView {
        let keyContentView = UITextView(i: CGRectZero, textFC: JTextFC(f: kFont_Size14, c: kColor_Blue)).funj_addCornerLayer(JFilletValue(w: 1, r: 5, c: kColor_Red))
        self.view.addSubview(keyContentView)
        keyContentView.layer.masksToBounds = false
        keyContentView.backgroundColor = kColor_White
        keyContentView.delegate = self
        keyContentView.isHidden = true
        keyContentView.autocorrectionType = .no
        
        let label = UILabel(i: CGRect(x: 0, y: -10, width: 200, height: 20), title: title, textFC: JTextFC(f: kFont_Size12, c: kColor_Orange, a: .left))
        keyContentView.addSubview(label)
        
        let path2 = NSHomeDirectory() + "/Documents/logminer/\(path)";
        let url2 = URL(fileURLWithPath: path2)
        keyContentView.text = try? String(contentsOf: url2, encoding: .utf8) ?? ""
        return keyContentView
    }
    func funj_getKeyContentItem() {
        let string = m_keyContentView!.text
        let array = string!.components(separatedBy: "\n")
        var saveKeyColorDic : [String : UIColor] = [:]
        for (key, value) in self.m_saveKeyColorDic {
            saveKeyColorDic[key] = value
        }
        self.m_saveKeyColorDic.removeAll()
        for key in array {
            if key.count > 0 {
                if saveKeyColorDic[key] == nil {
                    m_saveKeyColorDic[key] = krandomColors(alpha: 0.5)
                } else {
                    m_saveKeyColorDic[key] = saveKeyColorDic[key]
                }
            }
        }
        logMainContentView?.keyDic = self.m_saveKeyColorDic
        for logContentView in self.saveDataArr {
            logContentView.keyDic = self.m_saveKeyColorDic
        }
    }
    func funj_getMatchContentItem() {
        let string = m_matchContentView!.text
        let array = string!.components(separatedBy: "\n")
        
        var saveKeyColorDic : [String : UIColor] = [:]
        for (key, value) in self.m_saveMatchColorDic {
            saveKeyColorDic[key] = value
        }
        self.m_saveMatchColorDic.removeAll()
        for key in array {
            if key.count > 0 {
                if saveKeyColorDic[key] == nil {
                    m_saveMatchColorDic[key] = krandomColors(alpha: 0.8)
                } else {
                    m_saveMatchColorDic[key] = saveKeyColorDic[key]
                }
            }
        }
        logMainContentView?.m_saveMatchColorDic = self.m_saveMatchColorDic
        for logContentView in self.saveDataArr {
            logContentView.m_saveMatchColorDic = self.m_saveMatchColorDic
        }
    }
    func funj_addLogFileItemView() {
        logFileItemView = JLogFileItemView();
        self.view.addSubview(logFileItemView!.view)
        logFileItemView?.view.layer.borderWidth = 2;
        logFileItemView?.view.layer.borderColor = kColor_Red.cgColor
        logFileItemView?.view?.isHidden = true
        
        logFileItemView?.m_logFileCallback = { [weak self] (path, title, dataArr) in
            if ((self?.saveDataDic[title]) != nil) {
                return
            }
            self?.saveDataDic[title] = ""
            let logMainContentView = JLogContentTableView()
            logMainContentView.titleLabel?.text = title;
            logMainContentView.m_savePath = path
            logMainContentView.backgroundColor = krandomColors(alpha: 0.05)
            logMainContentView.m_dataArray.removeAll()
            logMainContentView.m_dataArray += dataArr
            logMainContentView.keyDic = self!.m_saveKeyColorDic
            logMainContentView.m_startDate1 = self?.m_prefixTF22?.text ?? ""
            logMainContentView.m_endDate1 = self?.m_prefixTF23?.text ?? ""
            logMainContentView.funj_reloadButton()
            logMainContentView.funj_reloadData()
            self?.saveDataArr.append(logMainContentView)
            self?.m_dataArr.append("")
            self?.logMainContentView!.isHidden = true
            self?.view.setNeedsLayout()
            let index  = CGFloat(self?.m_dataArr.count ?? 0) - 1
            self?.m_collectionView.reloadData()
            let count : CGFloat = CGFloat((self?.m_textField!.text as NSString? ?? "1").floatValue)
            let index2 = Int(index / count)
            self?.m_collectionView.setContentOffset(CGPoint(x: CGFloat(index2) * (self?.m_collectionView.width ?? 0), y: 0), animated: true)
            
            let button = UIButton(i: CGRect(x: (self?.view.width ?? 30) - 30, y: CGFloat(25 * (self?.m_dataArr.count ?? 0)) + kStatusBarHeight + 50, width: 30, height: 20), title: title, textFC: JTextFC(f: kFont_Size11, c: kColor_White))
                .funj_add(targe: self, action: "selectPageTo:", tag: 100300 + (self?.m_dataArr.count ?? 0))
            button.backgroundColor = kColor_Orange
            button.width = JAppUtility.funj_getTextWidthWithView(button) + 10
            self?.view.addSubview(button)
        }
    }
    @objc func funj_selectActionTo(_ sender : UIButton? = nil ) {
        if(sender!.tag == 1001) {
            self.logFileItemView!.view.isHidden = !self.logFileItemView!.view.isHidden;
            m_keyContentView?.isHidden = true
            m_keyDeleteContentView?.isHidden = true
            m_matchContentView?.isHidden = true
            logMainContentView?.isHidden = true
            self.logFileItemView?.funj_reloadDatas()
        } else if(sender!.tag == 1002) {
            self.view.setNeedsLayout()
            self.textViewShouldEndEditing(self.m_keyContentView!)
            self.logMainContentView?.funj_reloadData()
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_reloadData()
            }
        } else if(sender!.tag == 1003) {
            self.m_isOnlyShowInfo = !self.m_isOnlyShowInfo
            for logMainContentView in self.saveDataArr {
                logMainContentView.m_isOnlyShowInfo = self.m_isOnlyShowInfo
                logMainContentView.funj_reloadData()
            }
        } else if(sender!.tag == 1004) {
            m_keyDeleteContentView?.isHidden = !m_keyDeleteContentView!.isHidden
            if m_keyDeleteContentView!.isHidden {
                self.funj_reloadToDeleteValue()
            }
        } else if(sender!.tag == 1005) {
            self.logMainContentView!.isHidden = !self.logMainContentView!.isHidden;
            self.funj_reloadAllToMain()
        } else if(sender!.tag == 1006) {
            m_keyContentView?.isHidden = !m_keyContentView!.isHidden
            self.logFileItemView!.view.isHidden = true
            m_keyDeleteContentView?.isHidden = true
            m_matchContentView?.isHidden = true
            
            self.textViewShouldEndEditing(self.m_keyContentView!)
            self.m_collectionView .reloadData()
            self.logMainContentView?.funj_reloadData()
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_reloadData()
            }
        } else if(sender!.tag == 1007) {
            m_keyContentView?.isHidden = true
            m_keyDeleteContentView?.isHidden = true
            m_matchContentView?.isHidden = !m_matchContentView!.isHidden
            self.textViewShouldEndEditing(self.m_matchContentView!)
            
            if m_matchContentView!.isHidden {
                self.logMainContentView?.funj_reloadToMatchValue()
                for logMainContentView in self.saveDataArr {
                    logMainContentView.funj_reloadToMatchValue()
                }
            }
        }
    }
    @objc func selectPageTo(_ sender : UIButton? = nil ) {
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        let index = Int((sender!.tag - 100301) / count)
        self.m_collectionView.setContentOffset(CGPoint(x: CGFloat(index) * self.m_collectionView.width , y: 0), animated: true)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.isEqual(to: m_prefixTF22) || textField.isEqual(to: m_prefixTF23) {
            var startkey = "startTimeDefault"
            if textField.isEqual(to: m_prefixTF23) {
                startkey = "endTimeDefault"
            }
            UserDefaults.standard.set(textField.text, forKey: startkey)
            self.funj_reloadAllToMain()
            self.logMainContentView?.funj_updateToScrollCell(textField.text!)
            for logMainContentView in self.saveDataArr {
                logMainContentView.funj_updateToScrollCell(textField.text!)
            }
        }
        self.view.setNeedsLayout()
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        var string = textView.text
        let array = string!.components(separatedBy: "\n")
        var keyDic:[String : String] = [:]
        var newArray : [String] = []
        for key in array {
            if key.count > 0 {
                if keyDic[key] == nil {
                    newArray.append(key)
                }
                keyDic[key] = ""
            }
        }
        string = newArray.joined(separator: "\n")
        
        var path1 = "logkeyfile"
        if textView == m_keyDeleteContentView {
            path1 = "logDelkeyfile"
        } else if textView == m_matchContentView {
            path1 = "logMatchkeyfile"
            self.funj_getMatchContentItem()
        } else {
            self.funj_getKeyContentItem()
        }
        
        let path = NSHomeDirectory() +  "/Documents/logminer/\(path1)" ;
        let url = URL(fileURLWithPath: path)
        try? string?.write(to: url, atomically: true, encoding: .utf8)
        return true
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        m_collectionView.frame = CGRect(x: 0, y: kStatusBarHeight + 30, width: self.view.width, height: self.view.height - kStatusBarHeight - 30)
        logMainContentView?.frame = CGRect(x: 0, y: self.logMainContentView!.m_splitTopPoint, width: self.view.width, height: self.view.height - self.logMainContentView!.m_splitTopPoint)
        let bgView = self.view.viewWithTag(5000)
        bgView?.width = self.view.width
        
        logFileItemView?.view.frame = CGRect(x: (self.view.width - 350)/2, y: (self.view.height - 500)/2, width: 350, height: 500);
        m_keyContentView?.frame = CGRect(x: (self.view.width - 350)/2, y: (self.view.height - 500)/2, width: 350, height: 500);
        m_keyDeleteContentView?.frame = m_keyContentView!.frame
        m_matchContentView?.frame = m_keyContentView!.frame
        m_textField?.left = self.view.width - 60;
        
        m_prefixTF22?.left = self.view.width - 360; m_prefixTF22?.width = 180
        m_prefixTF22?.top = self.view.height - 20;
        m_prefixTF23?.left = self.view.width - 180;m_prefixTF23?.width = 180;
        m_prefixTF23?.top = self.view.height - 20;

        for button in self.view.subviews {
            if button.tag >= 100300 {
                button.left = self.view.width - button.width - 10
            }
        }
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        for logContentView in self.saveDataArr {
            logContentView.width = self.m_collectionView.width / CGFloat(count)
            logContentView.height = self.m_collectionView.height
        }
        self.m_collectionView.reloadData()
    }
}

extension JMainViewController {
    override func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let count : Int = Int(self.m_textField!.text ?? "1") ?? 1
        return CGSize(width: self.view.width / CGFloat(count), height: collectionView.height)
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: kCellIndentifier, for: indexPath)
        let index : Int = Int(self.m_textField!.text ?? "1") ?? 1
        let logContentView = self.saveDataArr[indexPath.row]
        for view in cell.contentView.subviews {
            view.removeFromSuperview()
        }
        logContentView.width = collectionView.width / CGFloat(index)
        logContentView.height = collectionView.height
        cell.contentView.addSubview(logContentView)
        return cell
    }
}

extension JMainViewController {
    func funj_reloadAllToMain() {
        let first1 = self.m_prefixTF22!.text
        let last1 = self.m_prefixTF23!.text
        
        logMainContentView!.m_startDate1 = self.m_prefixTF22?.text ?? ""
        logMainContentView!.m_endDate1 = self.m_prefixTF23?.text ?? ""
        let index = Int(logMainContentView?.m_prefixTF?.text ?? "36")!

        var saveAllArr : [String] = []
        for logContentView in self.saveDataArr  {
            logContentView.m_startDate1 = self.m_prefixTF22?.text ?? ""
            logContentView.m_endDate1 = self.m_prefixTF23?.text ?? ""
            logContentView.funj_reloadData()
            if logMainContentView!.isHidden { continue }
            
            let color = krandomColors(alpha: 0.2)
            for array in logContentView.m_dataArray {
                for str in array {
                    let key11 = (str as NSString).substring(to: min(index, str.count)) as! String
                    if key11 < first1! || key11 > last1! {
                        continue
                    }

                    for (key,_) in self.m_saveKeyColorDic {
                        if str.contains(key) {
                            saveAllArr.append(str)
                            logMainContentView?.saveMainBgDic[str] = color;
                            break
                        }
                    }
                }
            }
        }
        if logMainContentView!.isHidden { return }

        let first = logMainContentView?.m_prefixTF1?.text
        let last = logMainContentView?.m_prefixTF2?.text
        
        saveAllArr = saveAllArr.sorted { key1, key2 in
            var key11 = (key1 as NSString).substring(to: min(key1.count, index))
            var key22 = (key2 as NSString).substring(to: min(key2.count, index))
            if first != nil && last != nil {
                key11 = key11.replacingOccurrences(of: first!, with: last!)
                key22 = key22.replacingOccurrences(of: first!, with: last!)
            }
            return key11 < key22
        }

        logMainContentView?.m_dataArray = [saveAllArr]
        logMainContentView?.funj_reloadData()
        logMainContentView?.funj_reloadButton()
    }
    func funj_reloadToDeleteValue() {
        let string = self.m_keyDeleteContentView?.text
        self.funj_solverDataArray(logMainContentView!)
        for logView in self.saveDataArr {
            self.funj_solverDataArray(logView)
        }
        
        let path = NSHomeDirectory() + "/Documents/logminer/logDelkeyfile";
        let url = URL(fileURLWithPath: path)
        try? string?.write(to: url, atomically: true, encoding: .utf8)
    }
    func funj_solverDataArray(_ logView : JLogContentTableView) {
        let string = self.m_keyDeleteContentView!.text
        let array = string!.components(separatedBy: "\n")
        for key in array {
            var dataArray : [[String]] = []
            for var array2 in logView.m_dataArray {
                array2.removeAll { key1 in
                    return (key1 ).contains(key)
                }
                dataArray.append(array2)
            }
            logView.m_dataArray.removeAll()
            logView.m_dataArray += dataArray
        }
        logView.funj_reloadData()
        logView.funj_reloadButton()
    }
}
