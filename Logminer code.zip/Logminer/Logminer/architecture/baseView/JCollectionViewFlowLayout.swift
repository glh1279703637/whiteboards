//
//  JCollectionViewFlowLayout.swift
//  Logminer
//
//  Created by Jeffrey on 2020/10/30.
//  Copyright © 2020 Jeffery. All rights reserved.
//

import Foundation
import UIKit

class JCollectionViewFlowLayout: UICollectionViewFlowLayout {
    
}
