## 为什么 `NSTimer` 有时候不好使？

因为创建的  `NSTimer` 默认是被加入到了 `defaultMode`，所以当 `Runloop` 的 `Mode` 变化时，当前的 `NSTimer` 就不会工作了。

