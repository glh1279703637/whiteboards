## 解释一下 `GCD` 在 `Runloop` 中的使用？

`GCD`由 子线程 返回到 主线程,只有在这种情况下才会触发 RunLoop。会触发 RunLoop 的 Source 1 事件。

