## 是否了解 `Type Encoding`?

不懂的可以看文档，中文名 - `类型编码`。

https://developer.apple.com/library/content/documentation/Cocoa/Conceptual/ObjCRuntimeGuide/Articles/ocrtTypeEncodings.html

