## `Category` 可不可以添加实例对象？为什么？
答案是不可以。   Category 的结构体内部没有容纳 Ivar 的数据结构。

有很详细的分析，具体可以看[这篇文章](https://www.jianshu.com/p/dcc3284b65bf)

