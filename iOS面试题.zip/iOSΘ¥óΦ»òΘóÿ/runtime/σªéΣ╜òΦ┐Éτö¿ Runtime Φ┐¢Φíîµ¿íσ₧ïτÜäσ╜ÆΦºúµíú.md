## 如何运用 `Runtime` 进行模型的归解档

`Runtime` 遍历 `ivar_list`。

