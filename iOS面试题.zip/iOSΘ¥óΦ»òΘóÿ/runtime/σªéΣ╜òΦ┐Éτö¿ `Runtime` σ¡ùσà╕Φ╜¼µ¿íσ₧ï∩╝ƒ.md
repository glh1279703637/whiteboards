## 如何运用 `Runtime` 字典转模型？


`Runtime` 遍历 `ivar_list`,结合 `KVC` 赋值。


