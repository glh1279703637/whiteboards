## 讲一下 `@dynamic` 关键字？


`@dynamic` 意味着编译器不会帮助我们自动合成 `setter` 和 `getter` 方法。我们需要手动实现、这里就涉及到 `Runtime` 的动态添加方法的知识点。

