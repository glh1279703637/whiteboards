#### 一、UIView与CALayer

<单一职责原则>
UIView为CALayer提供内容，以及负责处理触摸等事件，参与响应链
CALayer负责显示内容contents