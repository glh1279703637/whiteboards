## 如何实现 `App` 换肤（夜间模式）？


扩利用 [DKNightVersion](https://github.com/Draveness/DKNightVersion) 完成。


同时可以参考一下[这篇文章](https://juejin.im/post/5af93d276fb9a07acf5644d3)。


